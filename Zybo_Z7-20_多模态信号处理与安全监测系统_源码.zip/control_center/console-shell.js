(()=>{
  const badges=[...document.querySelectorAll('[data-board-status]')].filter(node=>node.id!=='connection');
  if(!badges.length)return;
  const refresh=async()=>{
    try{
      const response=await fetch('/api/state?compact=1',{cache:'no-store'});
      if(!response.ok)throw new Error('status');
      const state=await response.json();
      const live=!!state.connected&&state.rx_age!==null&&Number(state.rx_age)<3;
      const waiting=!!state.connected&&!live;
      const port=state.port?String(state.port):'串口';
      const label=live?`${port} 已连接`:waiting?`${port} 等待回传`:'串口未连接';
      for(const badge of badges){badge.textContent=label;badge.dataset.state=live?'online':waiting?'waiting':'offline';}
    }catch{
      for(const badge of badges){badge.textContent='控制台服务不可用';badge.dataset.state='error';}
    }
  };
  refresh();
  window.setInterval(refresh,2500);
})();