param([Parameter(Mandatory=$true)][string]$Source,[Parameter(Mandatory=$true)][string]$Output,[string]$Bsp='E:/zybo/auto_hello/vitis_ws/hello_hw/ps7_cortexa9_0/standalone_domain/bsp/ps7_cortexa9_0',[string[]]$AdditionalSources=@(),[ValidateSet('0','1','2','3','s')][string]$Optimization='0',[string]$HeapSize='',[string]$LinkerScript='')
$ErrorActionPreference='Stop'
$taskGcc='E:/Xilinx/Vitis/2020.2/gnu/aarch32/nt/gcc-arm-none-eabi/bin'
$taskSupport='E:/zybo/auto_hello/vitis_ws/hello_world/src'
$activeLinkerScript=if($LinkerScript){$LinkerScript}else{"$taskSupport/lscript.ld"}
$linkerFlags=@("-Wl,-T,$activeLinkerScript","-Wl,-Map,$Output.map")
if($HeapSize){$linkerFlags+="-Wl,--defsym=_HEAP_SIZE=$HeapSize"}
& "$taskGcc/arm-none-eabi-gcc.exe" -mcpu=cortex-a9 -mfpu=vfpv3 -mfloat-abi=hard "-O$Optimization" -g3 -Wall -Wextra "-I$Bsp/include" "-I$taskSupport" "-specs=$taskSupport/Xilinx.spec" $linkerFlags "-L$Bsp/lib" $Source $AdditionalSources "$taskSupport/platform.c" '-Wl,--start-group' -lxil -lc -lm -lgcc '-Wl,--end-group' -o $Output
if($LASTEXITCODE -ne 0){throw 'ARM compile failed'}
& "$taskGcc/arm-none-eabi-size.exe" $Output
