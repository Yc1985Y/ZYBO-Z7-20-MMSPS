import json, numpy as np, wave
from pathlib import Path
from PIL import Image
p=Path('E:/zybo/control_center/live_acceptance_20261023')
cases=json.loads((p/'results.json').read_text(encoding='utf-8'))
a=cases[0]
pcm=np.frombuffer((p/('audio_%s_pcm.bin'%a['run_id'])).read_bytes(),dtype='<i2').astype(float)/32768
root=Path('E:/zybo/sensor_project/test_audio_samples')
def wav(name):
    with wave.open(str(root/name),'rb') as f:return np.frombuffer(f.readframes(f.getnframes()),dtype='<i2').astype(float)/32768
x=wav(a['filename']);y=wav('demo_01_clean_speech_reference.wav')
z=pcm/(a['result']['playback_gain_milli']/1000)
def snr(v):return float(10*np.log10(np.sum(y*y)/np.sum((v-y)**2)))
metrics={'audio_snr_input_db':snr(x),'audio_snr_output_db':snr(z)}
q=Path('E:/zybo/control_center/live_acceptance_20261022/quality_v60')
ref=np.array(Image.open(q/'clean.png')).astype(float)
def psnr(v):return float(10*np.log10(255**2/np.mean((ref-v)**2)))
for case in cases:
    if case['kind']!='image':continue
    w,h,c=case['checks']['size']
    out=np.frombuffer((p/('image_%s_pixels.bin'%case['run_id'])).read_bytes(),dtype=np.uint8).reshape(h,w,c)
    inp=np.array(Image.open(q/case['filename'])).astype(float)
    metrics[str(case['mode'])]={'input_psnr_db':psnr(inp),'output_psnr_db':psnr(out)}
    Image.fromarray(out).save(p/('image_%s.png'%case['run_id']))
(p/'metrics.json').write_text(json.dumps(metrics,indent=2),encoding='utf-8')
print(json.dumps(metrics,indent=2))
