const { chromium } = require('C:/Users/yc/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');

const base = 'http://127.0.0.1:8765';

(async () => {
  const browser = await chromium.launch({
    executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
    headless: true,
  });
  const results = [];
  const errors = [];
  try {
    const statePage = await browser.newPage();
    const liveState = await (await statePage.request.get(`${base}/api/state`)).json();
    if (!liveState.connected || liveState.rx_age > 3) throw new Error('Board status is not live');
    results.push(`live board status: ${liveState.port}, firmware V${liveState.telemetry.firmware_version}`);

    const page = await browser.newPage({ viewport: { width: 1450, height: 1100 } });
    page.on('pageerror', error => errors.push(error.message));

    await page.goto(`${base}/audio`);
    await page.locator('.demo-library-fold summary').click();
    await page.locator('.audio-demo-card').first().waitFor({ timeout: 5000 });
    if (await page.locator('.audio-demo-card').count() !== 5) throw new Error('Audio demo catalog did not load all five items');
    await page.locator('.advanced-filter-fold').first().locator('summary').click();
    await page.locator('.mode-card[data-mode="6"]').click();
    if (await page.locator('#filter').inputValue() !== '6') throw new Error('Audio filter selection did not update');
    await page.locator('#tab-phase').click();
    if (await page.locator('#tab-phase').getAttribute('aria-selected') !== 'true') throw new Error('Audio phase view tab did not switch');
    await page.locator('#file').setInputFiles('E:/zybo/sensor_project/test_audio_samples/demo_01_speech_static_noise.wav');
    await page.waitForFunction(() => !document.querySelector('#upload').disabled, { timeout: 5000 });
    results.push('audio page: live demo catalog, file selection, mode/view controls and idle submit readiness respond');

    let imageStatusCalls = 0;
    await page.route('**/api/image/status', route => { imageStatusCalls++; return route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ status: 'processing', run_id: 999, progress: 100 }),
    }); });
    await page.locator('#file').setInputFiles({
      name: 'guard-check.wav', mimeType: 'audio/wav', buffer: Buffer.from('RIFF0000WAVE'),
    });
    await page.waitForTimeout(1300);
    if (!(await page.locator('#upload').isDisabled()) || !(await page.locator('.audio-demo-card').evaluateAll(cards => cards.length === 5 && cards.every(card => card.disabled)))) {
      console.log('audio busy guard snapshot', { imageStatusCalls, uploadDisabled: await page.locator('#upload').isDisabled(), cards: await page.locator('.audio-demo-card').evaluateAll(cards => cards.map(card => card.disabled)), status: await page.locator('#status-text').textContent() });
      throw new Error('Audio buttons were not disabled during image processing');
    }
    await page.waitForFunction(() => document.querySelector('#upload').disabled &&
      [...document.querySelectorAll('.audio-demo-card')].length === 5 &&
      [...document.querySelectorAll('.audio-demo-card')].every(card => card.disabled), { timeout: 1000 });
    let audioPosts = 0;
    await page.route('**/api/audio/upload', route => { audioPosts++; return route.fulfill({ status: 409, body: '{}' }); });
    await page.locator('#upload').evaluate(element => element.dispatchEvent(new MouseEvent('click', { bubbles: true })));
    await page.waitForTimeout(250);
    if (audioPosts) throw new Error('Audio upload was submitted while image processing was active');
    results.push('audio/image mutual exclusion: upload and demo cards disable; forced click does not submit');

    await page.unroute('**/api/image/status');
    await page.route('**/api/image/status', route => route.fulfill({ status: 503, body: 'unavailable' }));
    await page.reload();
    await page.locator('#file').setInputFiles({
      name: 'guard-check.wav', mimeType: 'audio/wav', buffer: Buffer.from('RIFF0000WAVE'),
    });
    await page.waitForFunction(() => document.querySelector('#upload').disabled);
    await page.locator('#upload').evaluate(element => element.dispatchEvent(new MouseEvent('click', { bubbles: true })));
    await page.waitForTimeout(250);
    if (audioPosts) throw new Error('Audio upload was submitted after image-task status failed');
    results.push('audio/image status failure: upload fails closed');

    await page.unrouteAll();
    await page.goto(`${base}/`);
    await page.waitForFunction(() => document.querySelector('#connection').textContent.includes('已连接'), { timeout: 5000 });
    const imageNavigation = page.locator('.site-nav a[href="/image"]');
    if (await imageNavigation.count() !== 1) throw new Error('Image navigation does not open the image lab directly');
    await imageNavigation.click();
    await page.waitForURL(`${base}/image`);
    if (!(await page.locator('#file').count()) || !(await page.locator('#route-ai').isVisible())) {
      throw new Error('Direct image navigation did not expose the upload and ARM AI controls');
    }
    await page.goto(`${base}/`);
    await page.waitForFunction(() => document.querySelector('#connection')?.textContent.includes('已连接'), { timeout: 5000 });
    const embeddedImage = page.frameLocator('#image-lab-frame');
    await embeddedImage.locator('#run').waitFor({ timeout: 5000 });
    await embeddedImage.locator('#route-ai').click();
    if (await embeddedImage.locator('#route-ai').getAttribute('aria-pressed') !== 'true') throw new Error('Embedded image AI route did not switch');
    await embeddedImage.locator('#route-classic').click();
    await embeddedImage.locator('#file').setInputFiles('E:/zybo/sensor_project/test_image_samples/demo_08_golden_retriever_saltpepper_10pct.png');
    await page.waitForFunction(() => {
      const frame = document.querySelector('#image-lab-frame')?.contentWindow;
      return frame?.location.search.includes('embed=1') && frame.document.querySelector('#run')?.disabled === false;
    }, { timeout: 5000 });
    results.push('unified console: image iframe exposes routes and real ARM submit readiness; embed route survives file selection');
    await page.locator('#console-audio-file').setInputFiles('E:/zybo/sensor_project/test_audio_samples/demo_01_speech_static_noise.wav');
    await page.waitForFunction(() => !document.querySelector('#console-audio-run').disabled, { timeout: 5000 });
    await page.locator('.console-fold details > summary').first().click();
    await page.locator('#clear').click();
    if (await page.locator('#terminal').locator('div').count() !== 0) throw new Error('Clear-log button did not clear the visible log');
    await page.locator('[data-cmd="s"]').click();
    await page.waitForFunction(() => document.querySelector('#notice').textContent.includes('板子已确认执行：s'), { timeout: 5000 });
    results.push('overview: live connection, clear-log control and real serial status button/ACK respond');

    const taskState = structuredClone(liveState);
    taskState.audio.status = 'processing';
    taskState.image.status = 'complete';
    taskState.pc_ble.connected = true;
    taskState.pc_ble.connecting = false;
    await page.route('**/api/state*', route => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(taskState) }));
    await page.reload();
    await page.locator('#console-audio-file').setInputFiles('E:/zybo/sensor_project/test_audio_samples/demo_01_speech_static_noise.wav');
    await page.waitForFunction(() => !document.querySelector('#recover').disabled && document.querySelector('#console-audio-run').disabled &&
      [...document.querySelectorAll('[data-cmd]')].every(button => button.disabled) &&
      [...document.querySelectorAll('[data-ble]')].every(button => !button.disabled));
    results.push('overview busy state: new audio submit and USB controls disabled; BLE and exit/recovery remain available');

    taskState.audio.status = 'complete';
    taskState.image.status = 'processing';
    await page.reload();
    await page.locator('#console-audio-file').setInputFiles('E:/zybo/sensor_project/test_audio_samples/demo_01_speech_static_noise.wav');
    await page.waitForFunction(() => !document.querySelector('#recover').disabled && document.querySelector('#console-audio-run').disabled &&
      [...document.querySelectorAll('[data-cmd]')].every(button => !button.disabled) &&
      [...document.querySelectorAll('[data-ble]')].every(button => !button.disabled));
    results.push('image ARM-processing state: USB board controls remain available; file upload is gated and exit/recovery stays available');

    const imageState = structuredClone(liveState);
    imageState.audio.status = 'processing';
    imageState.image.status = 'complete';
    imageState.telemetry.image_worker_state = 5;
    await page.unroute('**/api/state*');
    await page.goto(`${base}/image`);
    await page.locator('.demo-library summary').first().click();
    await page.locator('.demo-card').first().waitFor({ timeout: 5000 });
    await page.locator('#file').setInputFiles('E:/zybo/sensor_project/test_image_samples/demo_08_golden_retriever_saltpepper_10pct.png');
    await page.waitForFunction(() => !document.querySelector('#run').disabled, { timeout: 5000 });
    results.push('image page: board-ready state and valid image make the real ARM submit button available');
    await page.route('**/api/state*', route => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(imageState) }));
    await page.reload();
    await page.locator('.demo-library summary').first().click();
    await page.locator('.demo-card').first().waitFor({ timeout: 5000 });
    await page.locator('#file').setInputFiles('E:/zybo/sensor_project/test_image_samples/demo_08_golden_retriever_saltpepper_10pct.png');
    await page.waitForFunction(() => document.querySelector('#run').disabled &&
      [...document.querySelectorAll('.demo-card')].length === 10 &&
      [...document.querySelectorAll('.demo-card')].every(card => card.disabled));
    if (await page.locator('#board-recover').isHidden() || await page.locator('#board-recover').isDisabled()) {
      throw new Error('Image-core exit/recovery must remain available while audio is running');
    }
    await page.locator('#route-ai').click();
    if (await page.locator('#route-ai').getAttribute('aria-pressed') !== 'true' || !(await page.locator('#classic-algorithms').isHidden())) {
      throw new Error('Image route selector did not switch to ARM AI');
    }
    await page.locator('#route-classic').click();
    if (await page.locator('#route-classic').getAttribute('aria-pressed') !== 'true' || !(await page.locator('#ai-algorithms').isHidden())) {
      throw new Error('Image route selector did not switch to traditional algorithms');
    }
    results.push('image busy state: run and demo cards disabled; exit/recovery remains available; algorithm route selectors respond');

    for (const path of ['/project', '/wiring']) {
      await page.goto(`${base}${path}`);
      if (!(await page.locator('h1').count())) throw new Error(`${path} did not render a page heading`);
    }
    results.push('project and wiring pages render with working navigation targets');

    if (errors.length) throw new Error(`Browser script errors: ${errors.join('; ')}`);
    console.log(JSON.stringify({ checks: results, pageErrors: errors }, null, 2));
  } finally {
    await browser.close();
  }
})().catch(error => { console.error(error); process.exit(1); });
