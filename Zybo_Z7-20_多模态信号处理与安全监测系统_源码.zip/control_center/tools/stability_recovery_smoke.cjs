const { chromium } = require('C:/Users/yc/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');

const base = 'http://127.0.0.1:8765';
const board = {
  connected: true,
  port: 'COM13',
  rx_age: 0.2,
  telemetry: { firmware_version: 57, image_cpu1_ready: 1, image_worker_state: 5, phase: 'sensor_monitor' },
  recovering: false,
  recovery_required: false,
  recovery_reason: '',
  recovery_error: '',
};
const audio = { status: 'idle', run_id: 0, started_at: null, filename: '', bytes: 0, progress: 0, message: '', result: null };
const image = { status: 'idle', run_id: 0, started_at: null, filename: '', bytes: 0, progress: 0, message: '', result: null };
let recoverRequests = 0;
let apiVersion = 6;

function recoverySnapshot(target) {
  return {
    recovering: board.recovering,
    recovery_required: board.recovery_required,
    recovery_reason: board.recovery_reason,
    recovery_error: board.recovery_error,
    api_version: apiVersion,
    ...target,
  };
}

function imageResponse() {
  return recoverySnapshot({ ...image, board_connected: board.connected, board_port: board.port, rx_age: board.rx_age });
}

function audioResponse() {
  return recoverySnapshot({
    ...audio,
    processor: 'Zynq ARM Cortex-A9',
    waveform: null,
    spectrum: null,
    frames: [],
    playback: null,
    board: board.telemetry,
    board_connected: board.connected,
    board_port: board.port,
    rx_age: board.rx_age,
  });
}

(async () => {
  const browser = await chromium.launch({
    executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
    headless: true,
  });
  const errors = [];
  try {
    const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
    page.on('pageerror', error => errors.push(error.message));
    page.on('dialog', dialog => dialog.accept());
    await page.route('**/api/**', async route => {
      const url = new URL(route.request().url());
      if (url.pathname === '/api/state') {
        return route.fulfill({ json: { ...board, telemetry: board.telemetry, audio, image, events: [], api_version: apiVersion } });
      }
      if (url.pathname === '/api/audio/status') return route.fulfill({ json: audioResponse() });
      if (url.pathname === '/api/image/status') return route.fulfill({ json: imageResponse() });
      if (url.pathname === '/api/audio/samples') return route.fulfill({ json: { samples: [] } });
      if (url.pathname === '/api/image/samples') return route.fulfill({ json: { samples: [] } });
      if (url.pathname === '/api/recover' && route.request().method() === 'POST') {
        recoverRequests++;
        board.recovering = true;
        board.recovery_required = true;
        board.recovery_reason = '正在退出任务并重载固件';
        audio.status = audio.status === 'idle' ? 'idle' : 'recovering';
        image.status = image.status === 'idle' ? 'idle' : 'recovering';
        return route.fulfill({ json: { started: true, message: '恢复已启动' } });
      }
      return route.fulfill({ status: 404, json: { error: 'unexpected API request' } });
    });

    audio.status = 'processing';
    audio.run_id = 1;
    audio.started_at = Date.now() / 1000 + 3;
    audio.filename = 'guard-check.wav';
    audio.bytes = 12;
    await page.goto(`${base}/audio`);
    await page.locator('#file').setInputFiles({ name: audio.filename, mimeType: 'audio/wav', buffer: Buffer.from('RIFF0000WAVE') });
    await page.waitForFunction(() => !document.querySelector('#audio-recover').hidden && !document.querySelector('#audio-recover').disabled);
    if (!(await page.locator('#upload').isDisabled())) throw new Error('Audio upload stayed enabled during active ARM processing');
    await page.locator('#audio-recover').click();
    await page.waitForFunction(() => document.querySelector('#audio-recover').disabled && document.querySelector('#upload').disabled);
    if (recoverRequests !== 1) throw new Error('Active audio task did not dispatch the recovery action');

    board.recovering = false;
    board.recovery_required = true;
    board.recovery_error = '未确认 CPU1 空闲';
    audio.status = 'error';
    await page.waitForFunction(() => !document.querySelector('#audio-recover').disabled && document.querySelector('#upload').disabled);
    board.recovery_required = false;
    board.recovery_error = '';
    board.recovery_reason = '';
    audio.status = 'cancelled';
    try {
      await page.waitForFunction(() => document.querySelector('#audio-recover').hidden, { timeout: 5000 });
    } catch (error) {
      const state = await page.evaluate(() => ({
        status: document.querySelector('#status')?.dataset.state,
        recoveryHidden: document.querySelector('#audio-recover')?.hidden,
        recoveryDisabled: document.querySelector('#audio-recover')?.disabled,
        uploadDisabled: document.querySelector('#upload')?.disabled,
        actionHint: document.querySelector('#action-hint')?.textContent,
      }));
      throw new Error(`Audio did not return to ready state after confirmed recovery: ${JSON.stringify(state)}; ${error.message}`);
    }
    await page.locator('#file').setInputFiles({ name: 'resumed.wav', mimeType: 'audio/wav', buffer: Buffer.from('RIFF0000WAVE') });
    await page.waitForFunction(() => !document.querySelector('#upload').disabled);

    board.recovery_required = true;
    board.recovery_reason = '板端任务状态未确认';
    image.status = 'error';
    image.run_id = 3;
    await page.goto(`${base}/image`);
    await page.waitForFunction(() => !document.querySelector('#board-recover').hidden && !document.querySelector('#board-recover').disabled);
    await page.locator('#board-recover').click();
    await page.waitForFunction(() => document.querySelector('#board-recover').disabled);
    if (recoverRequests !== 2) throw new Error('Image recovery control did not dispatch the recovery action');

    board.recovering = false;
    board.recovery_required = false;
    board.recovery_reason = '';
    image.status = 'cancelled';
    audio.status = 'cancelled';
    await page.waitForFunction(() => document.querySelector('#board-recover').hidden && document.querySelector('#status-title').dataset.state === 'idle');
    await page.locator('#file').setInputFiles({ name: 'ready.bmp', mimeType: 'image/bmp', buffer: Buffer.from('BM123456') });
    try {
      await page.waitForFunction(() => !document.querySelector('#run').disabled, { timeout: 5000 });
    } catch (error) {
      const state = await page.evaluate(() => ({
        imageState: document.body.dataset.imageState,
        runDisabled: document.querySelector('#run')?.disabled,
        runHint: document.querySelector('#run-hint')?.textContent,
        fileDisabled: document.querySelector('#file')?.disabled,
        fileMeta: document.querySelector('#file-meta')?.textContent,
        recoveryHidden: document.querySelector('#board-recover')?.hidden,
        boardStatus: document.querySelector('#board-state')?.dataset,
      }));
      throw new Error(`Image did not become ready after recovery: ${JSON.stringify(state)}; ${error.message}`);
    }

    apiVersion = 5;
    await page.goto(`${base}/audio`);
    await page.locator('#file').setInputFiles({ name: 'guard-check.wav', mimeType: 'audio/wav', buffer: Buffer.from('RIFF0000WAVE') });
    await page.waitForTimeout(1800);
    const oldAudioUi = await page.evaluate(() => ({ disabled: document.querySelector('#upload').disabled, hint: document.querySelector('#action-hint').textContent }));
    if (!oldAudioUi.disabled || !oldAudioUi.hint.includes('旧版本')) throw new Error(`Old audio API should fail closed: ${JSON.stringify(oldAudioUi)}`);
    await page.goto(`${base}/image`);
    await page.waitForFunction(() => document.querySelector('#board-label').textContent.includes('重启本地控制台服务'));
    if (!(await page.locator('#run').isDisabled())) throw new Error('Image submissions were not blocked by the old backend version');

    if (errors.length) throw new Error(`Browser errors: ${errors.join('; ')}`);
    console.log(JSON.stringify({ checks: [
      'audio processing exposes a real exit/recovery action and blocks new submission',
      'failed recovery remains locked; confirmed recovery allows a fresh audio selection and upload',
      'image recovery action works and a new image becomes selectable after recovery',
      'older server version fails closed and tells the user to restart the local console',
    ], recoverRequests, pageErrors: errors }, null, 2));
  } finally {
    await browser.close();
  }
})().catch(error => { console.error(error); process.exit(1); });
