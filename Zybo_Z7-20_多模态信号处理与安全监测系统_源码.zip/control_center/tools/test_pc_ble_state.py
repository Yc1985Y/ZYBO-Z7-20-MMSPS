import asyncio
import threading
import time
import unittest
from unittest.mock import patch

import pc_ble
from pc_ble import PcBle


class FakeDevice:
    address = PcBle.KNOWN_ADDRESS
    name = 'TestYan'


class FakeAdvertisement:
    local_name = 'TestYan'


class FakeScanner:
    instances = []
    active = 0
    max_active = 0
    lock = threading.Lock()

    def __init__(self, detection_callback=None, scanning_mode='active'):
        self.detection_callback = detection_callback
        self.running = False
        self.instances.append(self)

    async def start(self):
        with self.lock:
            self.running = True
            type(self).active += 1
            type(self).max_active = max(type(self).max_active, type(self).active)

    async def stop(self):
        with self.lock:
            if self.running:
                self.running = False
                type(self).active -= 1

    @classmethod
    def reset(cls):
        with cls.lock:
            cls.instances = []
            cls.active = 0
            cls.max_active = 0


class PcBleStateTests(unittest.TestCase):
    def setUp(self):
        FakeScanner.reset()

    def test_continuous_scan_matches_target_and_stops_cleanly(self):
        async def run():
            client = object.__new__(PcBle)
            client.lock = threading.RLock()
            client.state = {'attempt': 0}
            client.scan_requested = True
            client.event = lambda *_args: None
            with patch.object(pc_ble, 'BleakScanner', FakeScanner):
                task = asyncio.create_task(client._scan_for_target())
                for _ in range(50):
                    if FakeScanner.instances:
                        break
                    await asyncio.sleep(0.01)
                self.assertTrue(FakeScanner.instances)
                FakeScanner.instances[-1].detection_callback(FakeDevice(), FakeAdvertisement())
                result = await asyncio.wait_for(task, timeout=1)
                self.assertEqual(result[0].address, PcBle.KNOWN_ADDRESS)
                self.assertEqual(FakeScanner.active, 0)

                client.scan_requested = True
                task = asyncio.create_task(client._scan_for_target())
                for _ in range(50):
                    if len(FakeScanner.instances) == 2:
                        break
                    await asyncio.sleep(0.01)
                client.scan_requested = False
                self.assertIsNone(await asyncio.wait_for(task, timeout=1))
                self.assertEqual(FakeScanner.active, 0)

        asyncio.run(run())

    def test_stop_then_immediate_reconnect_keeps_one_worker_and_scanner(self):
        events = []
        client = None
        with patch.object(pc_ble, 'BleakScanner', FakeScanner):
            client = PcBle(lambda *row: events.append(row))
            deadline = time.monotonic() + 2
            while client.loop is None and time.monotonic() < deadline:
                time.sleep(0.01)
            self.assertIsNotNone(client.loop)
            client.connect()
            deadline = time.monotonic() + 2
            while not FakeScanner.instances and time.monotonic() < deadline:
                time.sleep(0.01)
            self.assertTrue(FakeScanner.instances)

            first_worker = client.worker
            client.stop()
            client.connect()
            time.sleep(0.1)
            self.assertIs(client.worker, first_worker)
            self.assertEqual(FakeScanner.active, 1)
            self.assertEqual(FakeScanner.max_active, 1)

            client.stop()
            self.assertTrue(first_worker.result(timeout=2) is None)
            self.assertEqual(FakeScanner.active, 0)

            client.connect()
            deadline = time.monotonic() + 2
            while len(FakeScanner.instances) < 2 and time.monotonic() < deadline:
                time.sleep(0.01)
            self.assertGreaterEqual(len(FakeScanner.instances), 2)
            self.assertEqual(FakeScanner.max_active, 1)
            client.stop()
            client.worker.result(timeout=2)
            self.assertEqual(FakeScanner.active, 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
