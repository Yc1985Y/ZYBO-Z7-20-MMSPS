"""Run each V40 photo edit through the live board and validate RGB return data."""

import argparse
import json
import time
import urllib.request
from pathlib import Path


CASE_STRENGTH = {1: 70, 2: 70, 4: 0, 7: 70, 8: 70, 9: 80, 10: 75,
                 11: 75, 12: 80, 13: 75, 14: 60, 15: 70,
                 16: 80, 17: 80}
DEFAULT_ALGORITHMS = (9, 10, 11, 12, 13, 14, 15)


def request_json(url, data=None, headers=None, timeout=30):
    request = urllib.request.Request(url, data=data, headers=headers or {},
                                     method="POST" if data is not None else "GET")
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", default="http://127.0.0.1:8765")
    parser.add_argument("--image", default=str(Path(__file__).parents[2] /
                                                 "sensor_project/test_image_samples/grace_hopper.jpg"))
    parser.add_argument("--timeout", type=int, default=60,
                        help="Maximum wait per ARM processing run, in seconds")
    parser.add_argument("--algorithms", type=int, nargs="+", default=DEFAULT_ALGORITHMS)
    args = parser.parse_args()
    base = args.base.rstrip("/")
    payload = Path(args.image).read_bytes()
    board = request_json(base + "/api/state")
    telemetry = board.get("telemetry") or {}
    if not board.get("connected") or int(telemetry.get("firmware_version", 0)) < 40:
        raise RuntimeError("a live V40 board is required")

    for algorithm in args.algorithms:
        if algorithm not in CASE_STRENGTH:
            raise ValueError("no demonstration strength configured for algorithm %d" % algorithm)
        strength = CASE_STRENGTH[algorithm]
        started = request_json(base + "/api/image/upload", data=payload, headers={
            "Content-Type": "application/octet-stream",
            "X-Image-Name": Path(args.image).name,
            "X-Image-Algorithm": str(algorithm),
            "X-Image-Strength": str(strength),
            "X-Image-Threshold": "0",
        })
        run_id = int(started["run_id"])
        deadline = time.monotonic() + args.timeout
        while True:
            status = request_json(base + "/api/image/status?run_id=" + str(run_id))
            if status.get("status") in ("complete", "error"):
                break
            if time.monotonic() >= deadline:
                raise RuntimeError("run %d timed out: %s" %
                                   (run_id, status.get("message", "unknown status")))
            time.sleep(0.35)
        if status["status"] != "complete":
            raise RuntimeError("algorithm %d failed: %s" %
                               (algorithm, status.get("message", "unknown error")))

        result = status.get("result") or {}
        if int(result.get("algorithm", -1)) != algorithm:
            raise RuntimeError("run %d returned the wrong algorithm" % run_id)
        output_request = urllib.request.Request(
            base + "/api/image/output?run_id=" + str(run_id))
        with urllib.request.urlopen(output_request, timeout=30) as response:
            pixels = response.read()
            width = int(response.headers["X-Image-Width"])
            height = int(response.headers["X-Image-Height"])
            channels = int(response.headers["X-Image-Channels"])
        expected_channels = 3 if algorithm >= 4 else 1
        if channels != expected_channels or len(pixels) != width * height * channels:
            raise RuntimeError("run %d returned an invalid pixel frame" % run_id)

        print(json.dumps({
            "algorithm": algorithm,
            "run_id": run_id,
            "processing_ms": round(int(result.get("processing_us", 0)) / 1000, 2),
            "ai_inference_ms": round(int(result.get("ai_inference_us", 0)) / 1000, 2),
            "dimensions": "%dx%d" % (width, height),
            "channels": channels,
            "returned_bytes": len(pixels),
            "median_input_output": [result.get("p50_input"), result.get("p50_output")],
            "contrast_input_output": [result.get("contrast_input"), result.get("contrast_output")],
        }, ensure_ascii=False), flush=True)

    print("PHOTO_EDIT_BATCH_OK", flush=True)


if __name__ == "__main__":
    main()
