import base64, hashlib, json, time, urllib.request, urllib.parse
from pathlib import Path
BASE='http://127.0.0.1:8765'
OUT=Path('E:/zybo/control_center/live_acceptance_20261023')
OUT.mkdir(exist_ok=True)
report=json.loads((OUT/'results.json').read_text(encoding='utf-8')) if (OUT/'results.json').exists() else []
def req(path,data=None,headers=None):
    return urllib.request.urlopen(urllib.request.Request(BASE+path,data=data,headers=headers or {}),timeout=20)
def api(path,data=None,headers=None):
    with req(path,data,headers) as r:return json.load(r)
def run(kind,path,mode):
    payload=path.read_bytes()
    headers={'Content-Type':'application/octet-stream'}
    if kind=='audio':headers.update({'X-Audio-Name':urllib.parse.quote(path.name),'X-Filter-Mode':str(mode)})
    else:headers.update({'X-Image-Name':urllib.parse.quote(path.name),'X-Image-Algorithm':str(mode),'X-Image-Strength':'70'})
    started=api('/api/'+kind+'/upload',payload,headers);rid=started['run_id']
    deadline=time.monotonic()+180
    while True:
        s=api('/api/'+kind+'/status?run_id='+str(rid))
        if s['status'] in ('error','cancelled'):raise RuntimeError(s['message'])
        if s['status']=='complete':break
        if time.monotonic()>deadline:raise TimeoutError(str(rid))
        time.sleep(1)
    assert s['run_id']==rid and s['filename']==path.name
    r=s['result']; assert r
    if kind=='audio':
        assert s['waveform'] and s['spectrum'] and len(s['frames'])>0
        p=s['playback'];pcm=b''.join(base64.b64decode(c) for c in p['chunks'])
        assert len(pcm)==p['bytes']==p['received_bytes']==p['sent_bytes']
        assert p['samples']*p['channels']*p['sample_bits']//8==len(pcm)
        assert 0<p['duration_ms']<=10000
        checks={'playback_ms':p['duration_ms'],'pcm_bytes':len(pcm),'frames':len(s['frames']),'waveform':True,'spectrum':True}
        (OUT/f'audio_{rid}_pcm.bin').write_bytes(pcm)
    else:
        assert r['algorithm']==mode
        with req('/api/image/output?run_id='+str(rid)) as response:
            pixels=response.read();w=int(response.headers['X-Image-Width']);h=int(response.headers['X-Image-Height']);c=int(response.headers['X-Image-Channels'])
        assert len(pixels)==w*h*c
        with req('/api/image/source?run_id='+str(rid)) as response:assert hashlib.sha256(response.read()).digest()==hashlib.sha256(payload).digest()
        checks={'size':[w,h,c],'source_hash_verified':True,'pixel_bytes':len(pixels)}
        (OUT/f'image_{rid}_pixels.bin').write_bytes(pixels)
    (OUT/f'{kind}_{rid}_state.json').write_text(json.dumps(s,ensure_ascii=False),encoding='utf-8')
    report.append({'kind':kind,'run_id':rid,'filename':path.name,'mode':mode,'checks':checks,'result':r})
    (OUT/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'kind':kind,'run_id':rid,'checks':checks},ensure_ascii=False),flush=True)
if __name__=='__main__':
    audio=Path('E:/zybo/sensor_project/test_audio_samples')
    image=Path('E:/zybo/control_center/live_acceptance_20261022/quality_v60')
    run('audio',audio/'demo_01_speech_static_noise.wav',12)
    run('image',image/'blur.png',8)
    run('audio',audio/'demo_06_bell_speech_5s.mp3',6)
    run('image',image/'impulse.png',2)
    s=api('/api/state?compact=1')
    assert not s['recovery_required'] and not s['error']
    assert s['telemetry']['image_worker_state']==5
    print('FINAL PASS '+json.dumps(s['telemetry'],ensure_ascii=False),flush=True)
