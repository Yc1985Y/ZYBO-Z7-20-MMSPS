import json,time,urllib.request
from pathlib import Path
ROOT=Path('E:/zybo/control_center/live_acceptance_20261023')
def api(path,data=None):
    body=json.dumps(data).encode() if data is not None else None
    with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:8765'+path,data=body,headers={'Content-Type':'application/json'}),timeout=15) as r:return json.load(r)
def state():return api('/api/state?compact=1')
report=[]
tests=[('led 5','F',{'mode':'manual','pl_led':5}),('led 10','K',{'mode':'manual','pl_led':10}),('led 0','A',{'mode':'manual','pl_led':0}),('chase','r',{'mode':'chase'}),('breathe','e',{'mode':'breathe'}),('distance alarm','g',{'safety_enabled':1,'alarm_source':'distance'}),('distance +',']',{}),('distance -','[',{}),('guard','o',{'safety_enabled':1}),('status','s',{})]
for command,ack,expected in tests:
    before=state();api('/api/ble/send',{'command':command});deadline=time.monotonic()+5
    while True:
        s=state();b=s['pc_ble'];t=s['telemetry']
        if b['last_ack']=='ACK '+ack and not b['pending'] and t['ble_commands']>before['telemetry']['ble_commands']:
            if all(t.get(k)==v for k,v in expected.items()):break
        if time.monotonic()>deadline:raise RuntimeError(json.dumps({'command':command,'expected':expected,'state':s},ensure_ascii=False))
        time.sleep(.15)
    if command in ('distance +','distance -'):
        delta=50 if command.endswith('+') else -50
        assert t['distance_threshold_mm']==before['telemetry']['distance_threshold_mm']+delta
    samples=[]
    for _ in range(4):samples.append(state()['telemetry']);time.sleep(.15)
    report.append({'command':command,'ack':b['last_ack'],'state':t,'samples':samples})
    (ROOT/'ble_sonar_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'command':command,'ack':b['last_ack'],'mode':t['mode'],'led':t['pl_led'],'safety':t['safety_enabled']},ensure_ascii=False),flush=True)
print('PASS',flush=True)
