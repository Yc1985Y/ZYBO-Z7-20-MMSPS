const { chromium } = require('C:/Users/yc/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs = require('node:fs');

const base = 'http://127.0.0.1:8765';
const imagePath = 'E:/zybo/sensor_project/test_image_samples/demo_08_golden_retriever_saltpepper_10pct.png';
const audioPath = 'E:/zybo/sensor_project/test_audio_samples/demo_01_speech_static_noise.wav';

(async () => {
  const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  const pageErrors = [];
  page.on('pageerror', error => pageErrors.push(error.message));
  try {
    const state = await (await page.request.get(`${base}/api/state?compact=1`)).json();
    const terminalStates = new Set(['idle', 'complete', 'error', 'cancelled']);
    if (!state.connected || Number(state.telemetry?.firmware_version) < 48 || Number(state.telemetry?.image_cpu1_ready) !== 1 ||
        state.recovering || state.recovery_required || !terminalStates.has(state.audio?.status) || !terminalStates.has(state.image?.status)) {
      throw new Error('Board, CPU1 image core, or task/recovery state is not ready');
    }

    await page.goto(`${base}/#image-lab`);
    const image = page.frameLocator('#image-lab-frame');
    await image.locator('#run').waitFor({ timeout: 10000 });
    await image.locator('#file').setInputFiles(imagePath);
    await image.locator('input[name="algorithm"][value="2"]').check();
    await image.locator('#strength').evaluate(element => {
      element.value = '100';
      element.dispatchEvent(new Event('input', { bubbles: true }));
    });
    await page.waitForFunction(() => {
      const frame = document.querySelector('#image-lab-frame')?.contentWindow;
      return frame?.location.search.includes('embed=1') && frame.document.querySelector('#run')?.disabled === false;
    }, { timeout: 10000 });

    const imageUploadResponse = page.waitForResponse(response => response.url().includes('/api/image/upload'));
    await image.locator('#run').click();
    const imageUpload = await imageUploadResponse;
    if (!imageUpload.ok()) throw new Error(`ARM image upload failed: HTTP ${imageUpload.status()}`);
    const acceptedImage = await (await page.request.get(`${base}/api/image/status`)).json();
    if (Number(acceptedImage.run_id) < 1 || !['queued', 'sending', 'receiving', 'processing', 'returning_results', 'complete'].includes(acceptedImage.status)) {
      throw new Error(`No active image run after successful upload: ${JSON.stringify(acceptedImage)}`);
    }
    const audioUpload = await page.request.post(`${base}/api/audio/upload`, {
      data: fs.readFileSync(audioPath),
      headers: {
        'Content-Type': 'application/octet-stream',
        'X-Filter-Mode': '12',
        'X-Audio-Name': 'concurrency-guard-check.wav',
      },
    });
    const audioBody = await audioUpload.json();
    if (audioUpload.status() !== 409 || !String(audioBody.error || '').includes('仍在运行')) {
      throw new Error(`Audio must be rejected while image owns the ARM/UART: HTTP ${audioUpload.status()} ${JSON.stringify(audioBody)}`);
    }

    const deadline = Date.now() + 60000;
    let imageStatus;
    do {
      const response = await page.request.get(`${base}/api/image/status?run_id=${acceptedImage.run_id}`);
      if (!response.ok()) throw new Error(`Image status request failed: ${response.status()}`);
      imageStatus = await response.json();
      if (['complete', 'error'].includes(imageStatus.status)) break;
      await new Promise(resolve => setTimeout(resolve, 300));
    } while (Date.now() < deadline);
    if (imageStatus.status !== 'complete') throw new Error(`Image run did not complete: ${imageStatus.message || imageStatus.status}`);
    if (Number(imageStatus.result?.algorithm) !== 2) throw new Error('ARM returned the wrong image algorithm');

    const pixels = await page.request.get(`${base}/api/image/output?run_id=${acceptedImage.run_id}`);
    const pixelBytes = await pixels.body();
    const expectedBytes = Number(pixels.headers()['x-image-width']) * Number(pixels.headers()['x-image-height']) * Number(pixels.headers()['x-image-channels']);
    if (!pixels.ok() || pixelBytes.length !== expectedBytes || expectedBytes !== 320 * 240 * 3) {
      throw new Error(`ARM image result is incomplete: ${pixelBytes.length}/${expectedBytes} bytes`);
    }
    await page.waitForFunction(() => {
      const frame = document.querySelector('#image-lab-frame')?.contentWindow;
      return frame?.document.querySelector('#status-title')?.dataset.state === 'complete' &&
        frame.document.querySelector('#output-canvas')?.hidden === false;
    }, { timeout: 10000 });
    if (pageErrors.length) throw new Error(`Browser errors: ${pageErrors.join('; ')}`);

    console.log(JSON.stringify({
      imageRun: acceptedImage.run_id,
      imageStatus: imageStatus.status,
      algorithm: imageStatus.result.algorithm_name,
      armProcessingMs: Number(imageStatus.result.processing_us) / 1000,
      returnedPixels: pixelBytes.length,
      overlappingAudioStatus: audioUpload.status(),
      overlapMessage: audioBody.error,
      embeddedUrl: page.frames().find(frame => frame.url().includes('/image?'))?.url(),
      pageErrors,
    }, null, 2));
  } finally {
    await browser.close();
  }
})().catch(error => { console.error(error); process.exit(1); });
