import json,time,urllib.request
from pathlib import Path
def api(path,post=False):
    with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:8765'+path,data=b'' if post else None),timeout=10) as r:return json.load(r)
started=time.monotonic();api('/api/ble/stop',True)
deadline=started+20
while api('/api/state?compact=1')['pc_ble']['connected']:
    if time.monotonic()>deadline:raise TimeoutError('disconnect')
    time.sleep(.3)
disconnected=time.monotonic();api('/api/ble/connect',True);deadline=time.monotonic()+40
while True:
    s=api('/api/state?compact=1')
    if s['pc_ble']['connected'] and s['telemetry']['ble_connected']:break
    if time.monotonic()>deadline:raise TimeoutError('reconnect '+str(s['pc_ble']))
    time.sleep(.3)
r={'disconnect_s':disconnected-started,'reconnect_s':time.monotonic()-disconnected,'state':s}
Path('E:/zybo/control_center/live_acceptance_20261023/ble_reconnect.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'disconnect_s':r['disconnect_s'],'reconnect_s':r['reconnect_s'],'connected':s['pc_ble']['connected']},ensure_ascii=False))
