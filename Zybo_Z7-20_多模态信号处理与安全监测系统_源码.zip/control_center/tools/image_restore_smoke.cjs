const { chromium } = require('C:/Users/yc/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');

const base = 'http://127.0.0.1:8765';

(async () => {
  const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  try {
    const status = await (await page.request.get(`${base}/api/image/status`)).json();
    if (status.status !== 'complete' || Number(status.run_id) < 1) throw new Error('No completed ARM image run is available for restore verification');
    const runId = Number(status.run_id), algorithm = Number(status.result?.algorithm);
    await page.goto(`${base}/#image-lab`);
    let imageFrame = page.frames().find(frame => frame.url().includes('/image?embed=1'));
    if (!imageFrame) throw new Error('Unified console did not load its embedded image lab');
    await imageFrame.evaluate(({ runId, algorithm }) => {
      history.replaceState(null, '', `/image?embed=1&run_id=${runId}&algorithm=${algorithm}`);
    }, { runId, algorithm });
    await page.waitForFunction(id => new URL(location.href).searchParams.get('image_run_id') === String(id), runId, { timeout: 5000 });
    await page.reload();
    await page.waitForFunction(id => {
      const frame = document.querySelector('#image-lab-frame')?.contentWindow;
      return frame && new URL(frame.location.href).searchParams.get('run_id') === String(id);
    }, runId, { timeout: 10000 });
    imageFrame = page.frames().find(frame => { const url = new URL(frame.url()); return url.pathname === '/image' && url.searchParams.get('embed') === '1' && url.searchParams.get('run_id') === String(runId); });
    if (!imageFrame) throw new Error('Image run address was not restored into the iframe');
    await imageFrame.waitForFunction(() => document.querySelector('#status-title')?.dataset.state === 'complete' &&
      document.querySelector('#output-canvas')?.hidden === false, { timeout: 15000 });
    if (errors.length) throw new Error(`Browser errors: ${errors.join('; ')}`);
    console.log(JSON.stringify({
      restoredRun: runId,
      algorithm,
      overviewUrl: page.url(),
      imageFrameUrl: imageFrame.url(),
      outputCanvasVisible: await imageFrame.locator('#output-canvas').isVisible(),
      pageErrors: errors,
    }, null, 2));
  } finally {
    await browser.close();
  }
})().catch(error => { console.error(error); process.exit(1); });
