"""Run Node's parser over every inline script in a local HTML page."""

from __future__ import annotations

import re
import subprocess
import sys
import tempfile
from pathlib import Path


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: check_inline_scripts.py PAGE.html", file=sys.stderr)
        return 2
    page = Path(sys.argv[1])
    html = page.read_text(encoding="utf-8")
    scripts = re.finditer(r"<script\b([^>]*)>(.*?)</script\s*>", html,
                          flags=re.IGNORECASE | re.DOTALL)
    checked = 0
    for match in scripts:
        if re.search(r"\bsrc\s*=", match.group(1), flags=re.IGNORECASE):
            continue
        source = match.group(2).strip()
        if not source:
            continue
        with tempfile.NamedTemporaryFile("w", suffix=".js", encoding="utf-8",
                                         delete=False) as script_file:
            script_file.write(source)
            path = Path(script_file.name)
        try:
            subprocess.run(["node", "--check", str(path)], check=True)
        finally:
            path.unlink(missing_ok=True)
        checked += 1
    if not checked:
        print("no inline scripts found", file=sys.stderr)
        return 1
    print(f"JavaScript syntax passed for {checked} inline scripts")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
