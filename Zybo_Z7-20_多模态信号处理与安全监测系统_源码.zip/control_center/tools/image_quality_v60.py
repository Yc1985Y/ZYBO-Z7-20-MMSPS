"""Compare actual ARM pixels against controlled reference images."""
import hashlib
import json
import math
import time
import urllib.parse
import urllib.request
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from skimage.metrics import structural_similarity

BASE = 'http://127.0.0.1:8765'
ROOT = Path('E:/zybo/control_center/live_acceptance_20261022/quality_v60')
SAMPLES = Path('E:/zybo/sensor_project/test_image_samples')
ROOT.mkdir(parents=True, exist_ok=True)
REPORT = {'cases': [], 'checks': {}, 'complete': False}
if (ROOT/'results.json').exists():
    REPORT = json.loads((ROOT/'results.json').read_text(encoding='utf-8'))


def request(path, data=None, headers=None):
    return urllib.request.urlopen(urllib.request.Request(BASE + path, data=data, headers=headers or {}), timeout=15)


def api(path, data=None, headers=None):
    with request(path, data, headers) as response:
        return json.load(response)


def save():
    (ROOT/'results.json').write_text(json.dumps(REPORT, ensure_ascii=False, indent=2), encoding='utf-8')


def psnr(reference, image):
    mse = np.mean((reference.astype(np.float64)-image.astype(np.float64))**2)
    return 99.0 if mse == 0 else 10*math.log10(255**2/mse)


def ssim(reference, image):
    return float(structural_similarity(reference, image, channel_axis=2, data_range=255))


def run(name, path, mode, strength=70, threshold=0):
    previous = next((c for c in REPORT['cases'] if c['name']==name), None)
    if previous and (ROOT/(name+'_ARM.png')).exists():
        cached = np.array(Image.open(ROOT/(name+'_ARM.png')))
        if cached.ndim==2: cached=cached[:,:,None]
        return cached, previous['result']
    before = api('/api/state?compact=1')
    payload = path.read_bytes()
    upload = api('/api/image/upload', payload, {'Content-Type':'application/octet-stream',
        'X-Image-Name':urllib.parse.quote(path.name),'X-Image-Algorithm':str(mode),
        'X-Image-Strength':str(strength),'X-Image-Threshold':str(threshold)})
    rid = upload['run_id']
    deadline = time.monotonic()+190
    sent = False
    ack = False
    while time.monotonic() < deadline:
        state = api(f'/api/image/status?run_id={rid}')
        if state['status'] in ('error','cancelled'):
            raise RuntimeError(f'{name}: {state.get("message")}')
        if mode in (4,5) and state['status']=='processing' and not sent:
            api('/api/send', json.dumps({'command':'s'}).encode(), {'Content-Type':'application/json'})
            sent = True
            # Capture before pixel chunks can evict the ACK from the 600-event ring.
            for _ in range(20):
                observed=api('/api/state')
                ack=any(e.get('id',0)>before['seq'] and e.get('text')=='ACK s' for e in observed.get('events',[]))
                if ack: break
                time.sleep(.1)
        if state['status']=='complete':
            break
        time.sleep(.6)
    else:
        raise TimeoutError(f'{name}: board task {rid} did not finish')
    assert state['filename']==path.name
    result = state['result']
    assert result['algorithm']==mode
    with request(f'/api/image/output?run_id={rid}') as response:
        w=int(response.headers['X-Image-Width']);h=int(response.headers['X-Image-Height'])
        channels=int(response.headers['X-Image-Channels']);pixels=response.read()
    assert len(pixels)==w*h*channels
    with request(f'/api/image/source?run_id={rid}') as response:
        assert hashlib.sha256(response.read()).digest()==hashlib.sha256(payload).digest()
    image=np.frombuffer(pixels,dtype=np.uint8).reshape(h,w,channels).copy()
    Image.fromarray(image[:,:,0] if channels==1 else image).save(ROOT/(name+'_ARM.png'))
    after=api('/api/state')
    item={'name':name,'run_id':rid,'filename':path.name,'algorithm':mode,'strength':strength,
          'size':[w,h,channels],'processing_us':result['processing_us'],'source_hash_verified':True,
          'result':result,'distance_seq_before':before['telemetry']['distance_seq'],
          'distance_seq_after':after['telemetry']['distance_seq'],
          'safety_enabled':after['telemetry'].get('safety_enabled'),
          'ble_connected':after['telemetry'].get('ble_connected')}
    if sent:
        item['control_during_inference_ack']=ack
        assert item['control_during_inference_ack'], 'status command did not receive board ACK during inference'
    REPORT['cases'].append(item);save()
    print(json.dumps({'case':name,'run_id':rid,'size':item['size'],'arm_s':round(result['processing_us']/1e6,3)},ensure_ascii=True),flush=True)
    return image,result


def main():
    deadline=time.monotonic()+100
    while time.monotonic()<deadline:
        s=api('/api/state?compact=1');t=s.get('telemetry') or {}
        if s.get('connected') and not s.get('recovering') and not s.get('recovery_required') and t.get('firmware_version')==60 and t.get('image_worker_state')==5:
            break
        time.sleep(1)
    else: raise RuntimeError('V60 recovery not ready')
    REPORT['firmware']=60
    photo=Image.open(SAMPLES/'demo_02_golden_retriever.jpg').convert('RGB').resize((320,240),Image.Resampling.LANCZOS)
    natural=np.array(photo)
    clean=np.round(16+natural.astype(np.float32)*(223/255)).astype(np.uint8)
    Image.fromarray(clean).save(ROOT/'clean.png')
    photo.save(ROOT/'natural.png')
    rng=np.random.default_rng(20261022);noisy=clean.copy();mask=rng.random(clean.shape[:2])<.10
    noisy[mask]=np.where(rng.random(mask.sum())[:,None]<.5,0,255)
    Image.fromarray(noisy).save(ROOT/'impulse.png')
    Image.fromarray(clean).filter(ImageFilter.GaussianBlur(.85)).save(ROOT/'blur.png')
    geometry=Image.new('RGB',(256,192),(25,25,25));draw=ImageDraw.Draw(geometry)
    draw.rectangle((15,20,65,80),fill=(220,220,220));draw.ellipse((95,25,155,85),fill=(200,200,200));draw.rectangle((180,110,230,165),fill=(230,230,230))
    geometry.save(ROOT/'geometry.bmp')
    baseline,_=run('clean_baseline',ROOT/'clean.png',0)
    assert np.array_equal(baseline,clean),'lossless RGB decode changed pixels'
    preserved,_=run('clean_median',ROOT/'clean.png',2,100)
    assert np.array_equal(baseline,preserved),'switching median damaged non-clipped texture'
    REPORT['checks']['clean_median_unchanged']=True
    restored,_=run('impulse_median',ROOT/'impulse.png',2,100)
    gain=psnr(clean,restored)-psnr(clean,noisy)
    REPORT['checks']['impulse_psnr']={'input_db':psnr(clean,noisy),'output_db':psnr(clean,restored),'gain_db':gain,'ssim_input':ssim(clean,noisy),'ssim_output':ssim(clean,restored)}
    assert gain>=6,'impulse removal gain below 6 dB'
    natural_out,_=run('natural_median',ROOT/'natural.png',2,100)
    changed=float(np.mean(np.any(natural_out!=natural,axis=2)))
    REPORT['checks']['natural_preservation']={'changed_pixel_fraction':changed,'ssim':ssim(natural,natural_out)}
    assert changed<.01 and ssim(natural,natural_out)>.995,'natural image detail loss'
    blur_base,_=run('blur_baseline',ROOT/'blur.png',0)
    zero,_=run('sharpen_zero',ROOT/'blur.png',8,0)
    assert np.array_equal(blur_base,zero),'zero sharpening is not a bypass'
    sharp,_=run('blur_sharpen',ROOT/'blur.png',8,70)
    REPORT['checks']['blur_quality']={'input_db':psnr(clean,blur_base),'output_db':psnr(clean,sharp),'ssim_input':ssim(clean,blur_base),'ssim_output':ssim(clean,sharp)}
    assert psnr(clean,sharp)>psnr(clean,blur_base),'sharpening did not improve reference PSNR'
    assert ssim(clean,sharp)>ssim(clean,blur_base),'sharpening did not improve reference SSIM'
    edges,er=run('geometry_edges',ROOT/'geometry.bmp',3,70,0)
    REPORT['checks']['geometry_components']=er['component_count']
    assert er['component_count']==3,'wrong connected component count'
    archive=SAMPLES/'archive_1908_newsboy_scan640.jpg'
    archive_base,_=run('archive_baseline',archive,0)
    archive_sharp,ar=run('archive_sharpen',archive,8,70)
    assert list(archive_sharp.shape)==[480,344,3],'full-resolution workspace regression'
    assert ar['sharpness_output']>ar['sharpness_input']
    _,cr=run('ai_panda',SAMPLES/'demo_21_red_panda.jpg',4)
    assert cr['ai_top5'][0]['label']=='lesser panda'
    _,dr=run('ai_airplanes',SAMPLES/'demo_15_nasa_shuttle_carrier.jpg',5,35,45)
    assert sum(x['label']=='airplane' for x in dr['detections'])>=2
    final,_=run('post_ai_clean_baseline',ROOT/'clean.png',0)
    assert np.array_equal(final,baseline),'task state or image data leaked across runs'
    REPORT['checks']['zero_strength_bypass']=True
    REPORT['checks']['post_ai_pixels_unchanged']=True
    REPORT.pop('error',None)
    REPORT['complete']=True;save()
    print(json.dumps(REPORT['checks'],ensure_ascii=True),flush=True)


if __name__=='__main__':
    try: main()
    except Exception as error:
        REPORT['error']=str(error);save();raise
