from pathlib import Path
from docx import Document
import hashlib,json
p=Path('D:/桌面/通信与电子系统设计/数字基带信号传输/实验报告模板.docx')
d=Document(p)
print('SHA',hashlib.sha256(p.read_bytes()).hexdigest())
for i,s in enumerate(d.sections):print('SECTION',i,s.page_width,s.page_height,s.top_margin,s.bottom_margin,s.left_margin,s.right_margin)
for i,para in enumerate(d.paragraphs):
    print('P',i,repr(para.text),'style',para.style.name,'align',para.alignment,'runs',[(r.text,r.font.name,r.font.size.pt if r.font.size else None,r.bold) for r in para.runs])
for i,t in enumerate(d.tables):
    print('TABLE',i,len(t.rows),len(t.columns))
    for j,row in enumerate(t.rows):print('ROW',j,[c.text for c in row.cells])
