if {[llength $argv] != 4} {error "Usage: download.tcl XSA BIT INIT_TCL ELF"}
lassign $argv hw bit init elf
connect
after 3000
if {[llength [targets -target-properties -filter {name =~ "*Cortex-A9*#0"}]] != 1} {error "Expected one CPU0 target"}
targets -set -filter {name =~ "*Cortex-A9*#0"}
rst -system
after 1000
fpga -file $bit
loadhw -hw $hw -mem-ranges [list {0x40000000 0xbfffffff}]
source $init
ps7_init
ps7_post_config
dow $elf
con
puts "BOARD_APPLICATION_STARTED"
disconnect
exit
