import asyncio
import threading
import time

from bleak import BleakClient, BleakScanner


class PcBle:
    KNOWN_ADDRESS = '44:B7:D0:2C:D6:76'
    SERVICE = '49535343-fe7d-4ae5-8fa9-9fafd205e455'
    TX = '49535343-1e4d-4bd9-ba61-23c647249616'
    RX = '49535343-8841-43f4-a8d4-ecbe34729bb3'
    COMMANDS = {
        'led 0', 'led 5', 'led 10', 'led 15', 'chase', 'bounce', 'breathe',
        'flash', 'distance alarm', 'distance +', 'distance -', 'status',
        'ack', 'guard', 'disarm'
    }

    def __init__(self, event):
        self.event = event
        self.lock = threading.RLock()
        self.loop = None
        self.client = None
        self.worker = None
        self.scan_requested = False
        self.auto_scan_enabled = True
        self.buffer = ''
        self.state = {
            'connected': False,
            'connecting': False,
            'scanning': False,
            'attempt': 0,
            'name': '',
            'address': '',
            'error': '',
            'last_rx': '',
            'last_ack': '',
            'sent': 0,
            'pending': ''
        }
        threading.Thread(target=self.run, daemon=True).start()

    def run(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def snapshot(self):
        with self.lock:
            result = dict(self.state)
            result['scan_requested'] = self.scan_requested
            return result

    def update(self, **values):
        with self.lock:
            self.state.update(values)

    def ensure_scanning(self):
        """Start automatic PC-side scanning once the board reports its BLE module."""
        with self.lock:
            if not self.auto_scan_enabled:
                return
        self.connect()

    def connect(self):
        with self.lock:
            if self.state['connected'] or self.scan_requested:
                return
            if self.loop is None:
                self.state.update(error='电脑蓝牙服务仍在启动', connecting=False, scanning=False)
                return
            self.auto_scan_enabled = True
            self.scan_requested = True
            self.state.update(connecting=True, scanning=True, attempt=0, error='')
            worker = self.worker
            if worker is not None and not worker.done():
                # Reuse the in-flight worker while it closes the prior link. Starting
                # a second loop here can orphan a connected GATT client and leave
                # RN4871 advertising disabled.
                worker.add_done_callback(self._resume_after_worker)
                self.state.update(error='正在结束上一条连接，完成后继续扫描')
                return
            self.worker = asyncio.run_coroutine_threadsafe(self._connection_loop(), self.loop)

    def _resume_after_worker(self, finished_worker):
        with self.lock:
            if self.worker is not finished_worker or not self.auto_scan_enabled or not self.scan_requested:
                return
            if self.loop is None:
                self.state.update(error='电脑蓝牙服务仍在启动', connecting=False, scanning=False)
                return
            self.state.update(connected=False, connecting=True, scanning=True, attempt=0, error='')
            self.worker = asyncio.run_coroutine_threadsafe(self._connection_loop(), self.loop)

    def stop(self):
        with self.lock:
            self.auto_scan_enabled = False
            self.scan_requested = False
            worker = self.worker
            self.state.update(connecting=False, scanning=False, pending='')
            if worker is None or worker.done():
                self.state.update(connected=False, connecting=False, scanning=False, pending='')
        # Do not cancel the asyncio task: cancellation can mark its Future done
        # before its GATT disconnect cleanup finishes. The scanner and client
        # observe the flag and close themselves before any restart.

    async def _scan_for_target(self):
        """Keep one BLE scan active until TestYan is found or scanning is stopped."""
        loop = asyncio.get_running_loop()
        discovered = loop.create_future()

        def on_advertisement(device, advertisement):
            address = str(device.address).replace('-', ':').upper()
            name = (advertisement.local_name or device.name or '').strip()
            if address != self.KNOWN_ADDRESS and name.casefold() != 'testyan':
                return

            def publish_match():
                if not discovered.done():
                    discovered.set_result((device, name or 'TestYan'))

            loop.call_soon_threadsafe(publish_match)

        scanner = BleakScanner(detection_callback=on_advertisement, scanning_mode='active')
        scanner_started = False
        try:
            await scanner.start()
            scanner_started = True
            next_report = time.monotonic() + 10
            while self.scan_requested and not discovered.done():
                remaining = max(0.1, next_report - time.monotonic())
                try:
                    return await asyncio.wait_for(asyncio.shield(discovered), timeout=min(0.5, remaining))
                except asyncio.TimeoutError:
                    if time.monotonic() >= next_report:
                        attempt = self.snapshot()['attempt'] + 1
                        self.update(
                            attempt=attempt,
                            error='仍在持续扫描 TestYan；设备出现后会自动连接'
                        )
                        if attempt == 1 or attempt % 3 == 0:
                            self.event('蓝牙', f'持续扫描 TestYan（第 {attempt} 轮）；找到后自动连接')
                        next_report = time.monotonic() + 10
            return discovered.result() if discovered.done() else None
        finally:
            if scanner_started:
                await scanner.stop()

    async def _connection_loop(self):
        try:
            while self.scan_requested:
                client = None
                self.update(connecting=True, scanning=True)
                try:
                    match = await self._scan_for_target()
                    if match is None or not self.scan_requested:
                        break
                    device, name = match
                    self.update(name=name, address=device.address, error='正在连接并检查无线串口服务…')
                    client = BleakClient(
                        device,
                        disconnected_callback=self._on_disconnected,
                        timeout=10
                    )
                    with self.lock:
                        self.client = client
                    await client.connect()
                    service = client.services.get_service(self.SERVICE)
                    if not service or not service.get_characteristic(self.RX) or not service.get_characteristic(self.TX):
                        raise RuntimeError('模块缺少已确认的无线串口服务')

                    self.buffer = ''
                    await client.start_notify(self.TX, self.receive)
                    self.update(connected=True, connecting=False, scanning=False, error='')
                    self.event('蓝牙', f'电脑已连接 {name}，无线接收已开启；断开后会继续扫描')

                    while self.scan_requested and client.is_connected:
                        await asyncio.sleep(0.5)

                    if client.is_connected:
                        await client.disconnect()
                    with self.lock:
                        if self.client is client:
                            self.client = None
                    if self.scan_requested:
                        self.update(connected=False, connecting=True, scanning=True, pending='', error='蓝牙连接已断开，正在重新扫描…')
                        self.event('蓝牙', '连接中断，自动重新扫描 TestYan')
                        await asyncio.sleep(1)

                except asyncio.CancelledError:
                    raise
                except Exception as ex:
                    if client is not None and client.is_connected:
                        try:
                            await client.disconnect()
                        except Exception:
                            pass
                    with self.lock:
                        if self.client is client:
                            self.client = None
                    self.update(
                        connected=False,
                        connecting=self.scan_requested,
                        scanning=self.scan_requested,
                        pending='',
                        error=f'{ex}；将继续扫描'
                    )
                    self.event('蓝牙', f'扫描或连接失败，将自动重试：{ex}')
                    if self.scan_requested:
                        await asyncio.sleep(2)
        finally:
            with self.lock:
                client = self.client
            if client is not None and client.is_connected:
                try:
                    await client.disconnect()
                except Exception:
                    pass
            with self.lock:
                if self.client is client:
                    self.client = None
                restart = self.auto_scan_enabled and self.scan_requested
                if restart:
                    self.state.update(connected=False, connecting=True, scanning=True, pending='', error='正在恢复扫描…')
                else:
                    self.scan_requested = False
                    self.state.update(connected=False, connecting=False, scanning=False, pending='')
            if restart:
                worker = self.worker
                if worker is not None:
                    worker.add_done_callback(self._resume_after_worker)
            else:
                self.event('蓝牙', '自动扫描已停止')

    def _on_disconnected(self, client):
        with self.lock:
            # Ignore a late callback from an old GATT link after a new client
            # has already taken ownership.
            if self.client is not client:
                return
            self.state.update(connected=False, pending='')

    def receive(self, characteristic, data):
        self.buffer += bytes(data).decode('ascii', 'replace')
        while '\n' in self.buffer:
            line, self.buffer = self.buffer.split('\n', 1)
            line = line.strip('\r')
            if not line:
                continue
            self.update(last_rx=line)
            self.event('蓝牙接收', line)
            if line.startswith('ACK '):
                self.update(last_ack=line, pending='', error='')
        if len(self.buffer) > 4096:
            self.buffer = ''

    def send(self, command):
        if command not in self.COMMANDS:
            raise ValueError('不支持的蓝牙命令')
        with self.lock:
            client = self.client
            if not self.state['connected'] or client is None:
                raise ValueError('请先连接电脑蓝牙')
            if self.state['pending']:
                raise ValueError('上一条无线命令还在等待确认')
            self.state['pending'] = command
            self.state['last_ack'] = ''
        asyncio.run_coroutine_threadsafe(self._send(client, command), self.loop)

    async def _send(self, client, command):
        try:
            if not client.is_connected:
                raise RuntimeError('蓝牙连接已断开，正在重新扫描')
            await client.write_gatt_char(self.RX, (command + '\n').encode(), response=True)
            self.update(sent=self.snapshot()['sent'] + 1)
            self.event('蓝牙发送', command)
            await asyncio.sleep(3)
            if self.snapshot()['pending'] == command:
                self.update(pending='', error='已无线发送，但未收到板子 ACK')
                self.event('蓝牙', '无线命令确认超时')
        except Exception as ex:
            self.update(pending='', error=str(ex))
            self.event('蓝牙', '发送失败：' + str(ex))
