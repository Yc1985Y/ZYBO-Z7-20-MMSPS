import sys, os, json, time, threading, logging, subprocess, shutil, zlib, struct, copy, base64, binascii
from pathlib import Path
from collections import deque
from logging.handlers import RotatingFileHandler
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlsplit, unquote, parse_qs
sys.path.insert(0, str(Path(__file__).parent / 'packages'))
import serial
from pc_ble import PcBle
from serial.tools import list_ports

ROOT = Path(__file__).parent
lock = threading.RLock()
port = None
events = deque(maxlen=600)
state = {'connected': False, 'port': 'COM13', 'baud': 921600, 'error': '', 'telemetry': {}, 'last_rx': 0, 'connected_since': 0, 'link_stale': False, 'seq': 0, 'recovering': False, 'recovery_required': False, 'recovery_reason': '', 'recovery_error': '', 'upload_generation': 0, 'image_worker_stage': '', 'image_worker_stage_since': 0}
audio_state = {'status':'idle','processor':'Zynq ARM Cortex-A9','run_id':0,'started_at':None,'completed_at':None,'filename':'','bytes':0,'progress':0,'message':'选择 WAV 或 MP3；文件分析由板端 ARM 执行。','result':None,'waveform':None,'spectrum':None,'frames':[],'playback':None,'led_state':'idle'}
image_state = {'status':'idle','processor':'Zynq ARM Cortex-A9','run_id':0,'started_at':None,'processing_started_at':None,'result_transfer_started_at':None,'completed_at':None,'filename':'','bytes':0,'source_bytes':b'','progress':0,'message':'选择 JPEG、PNG 或 BMP；解码与图像算法由板端 ARM 执行。','result':None,'output_bytes':bytearray(),'output_bytes_expected':0,'output_width':0,'output_height':0,'output_channels':1,'led_state':'idle'}
IMAGE_CACHE_DIR = ROOT / 'image_runs'
ACTIVE_TASK_PATH = ROOT / 'active_task.json'
IMAGE_SAMPLE_DIR = ROOT.parent / 'sensor_project' / 'test_image_samples'
AUDIO_SAMPLE_DIR = ROOT.parent / 'sensor_project' / 'test_audio_samples'
AUDIO_DEMO_CATALOG = [
    {'name':'demo_01_speech_static_noise.wav','title':'强噪声语音','category':'宽带底噪 · 自动降噪','note':'开头先听到单独底噪，后面语音被持续噪声盖住。自动配对干净参考，比较 ARM 处理前后的语音清晰度与底噪。','mode':12,'reference':'demo_01_clean_speech_reference.wav'},
    {'name':'demo_02_speech_50hz_hum.wav','title':'50 Hz 嗡声语音','category':'工频干扰 · 50 Hz 陷波','note':'低沉的电源嗡声叠在语音下方。运行板端陷波，并与同内容干净参考做动态评分。','mode':6,'reference':'demo_02_clean_speech_reference.wav'},
    {'name':'v26_mixed_50hz_hum_broadband.wav','title':'双重干扰信号','category':'50 Hz 嗡声 + 宽带底噪','note':'前半段是干扰底噪，后半段加入 1 kHz 有用信号。ARM 自动判断混合噪声并组合处理，可看低频谱线与宽带噪声的变化。','mode':12,'reference':'v26_mixed_50hz_clean_reference.wav'},
    {'name':'demo_03_1khz_tone_with_50hz_hum.wav','title':'双音分离','category':'1 kHz 有用音 + 50 Hz 干扰','note':'输入里 50 Hz 干扰比目标音更显眼；板端陷波后观察幅度谱和差值图，检查目标音是否保留。','mode':6,'reference':None},
    {'name':'demo_04_1khz_plus_4khz_lowpass.wav','title':'目标音与高频干扰','category':'1 kHz 保留 + 4 kHz 抑制','note':'两条稳定谱线分处通带和阻带。板端低通后，比较两处谱峰与时频差值。','mode':2,'reference':None},
]
AUDIO_SAMPLE_FILES = {name: name for item in AUDIO_DEMO_CATALOG for name in (item['name'], item.get('reference')) if name}
IMAGE_DEMO_CATALOG = [
    {'name':'archive_1908_newsboy_scan640.jpg','title':'1908 年小报童 · 低清历史扫描增强','category':'历史扫描 · ARM 多尺度清晰度增强','note':'用帽檐、衣褶和面部边缘查看板端增强；同一张板测图的高频残差仅小幅变化。','algorithm':8,'strength':70},
    {'name':'demo_09_golden_retriever_slight_blur.png','title':'模糊金毛照片 · 清晰度增强','category':'可控模糊对照 · ARM 多尺度锐化','note':'输入照片明显失焦，适合观察眼睛、鼻梁和围栏边缘变化；本次输出像素来自 ARM。','algorithm':8,'strength':70},
    {'name':'demo_08_golden_retriever_saltpepper_10pct.png','title':'金毛 10% 椒盐噪声 · 中值降噪','category':'可控噪声对照 · ARM 3×3 中值','note':'图像叠加 10% 黑白脉冲噪点；中值滤波针对这类孤立黑白点，普通干净照片不要使用。','algorithm':2,'strength':100},
    {'name':'demo_14_himalaya_lake.jpg','title':'喜马拉雅雪山 · 轮廓分割','category':'ARM Sobel + Otsu','note':'雪峰、岩壁和湖面层次分明；结果显示实际边缘掩码与板端区域计数。','algorithm':3,'threshold':65},
    {'name':'demo_21_red_panda.jpg','title':'小熊猫林间近景 · AI 分类','category':'ARM MobileNetV2 · ImageNet','note':'红棕色毛发与绿叶背景对比明显；查看板端实际返回的前五类别与分数。','algorithm':4,'strength':60},
    {'name':'demo_15_nasa_shuttle_carrier.jpg','title':'NASA 航拍双飞机 · AI 目标检测','category':'ARM SSD-MobileNet · COCO','note':'本板实测识别出两架飞机，置信度约 76% 和 73%；单张检测约需 72 秒。','algorithm':5,'strength':35},
    {'name':'demo_24_lighthouse_storm.jpg','title':'风暴夜港灯塔 · ARM 图像诊断','category':'板端亮度与直方图','note':'闪电高光、夜空暗部和海岸灯光同框；查看本张图片的板端统计，不改变原图。','algorithm':0},
]
IMAGE_DERIVED_NAMES = {
    'demo_08_golden_retriever_saltpepper_10pct.png',
    'demo_09_golden_retriever_slight_blur.png',
}
IMAGE_ARCHIVE_NAMES = {
    'archive_1908_newsboy_scan640.jpg',
}
for item in IMAGE_DEMO_CATALOG:
    item['kind'] = 'archive' if item['name'] in IMAGE_ARCHIVE_NAMES else 'derived' if item['name'] in IMAGE_DERIVED_NAMES else 'original'
IMAGE_SAMPLE_BY_NAME = {item['name']: item for item in IMAGE_DEMO_CATALOG}
serial_tx_lock = threading.Lock()
audio_upload_start = threading.Event()
audio_upload_ready = threading.Event()
audio_upload_chunk = threading.Event()
audio_upload_failed = threading.Event()
audio_upload_error = ''
audio_upload_count = 0
image_upload_start = threading.Event()
image_upload_ready = threading.Event()
image_upload_chunk = threading.Event()
image_upload_failed = threading.Event()
image_upload_error = ''
image_upload_count = 0
ACTIVE_AUDIO_STATES = ('queued','sending','receiving','waiting_board','processing','returning_results','returning_audio','recovering')
ACTIVE_IMAGE_STATES = ('queued','sending','receiving','processing','returning_results','recovering')
log = logging.getLogger('serial')
log.setLevel(logging.INFO)
handler = RotatingFileHandler(ROOT / 'serial_live.jsonl', maxBytes=5_000_000, backupCount=2, encoding='utf-8')
handler.setFormatter(logging.Formatter('%(message)s'))
log.addHandler(handler)

def event(direction, message):
    with lock:
        state['seq'] += 1
        row = {'id': state['seq'], 'time': time.strftime('%H:%M:%S'), 'direction': direction, 'text': message}
        events.append(row)
        log.info(json.dumps(row, ensure_ascii=False))

def _mark_recovery_required(reason):
    reason = str(reason or '板端任务状态无法确认')
    with lock:
        state.update(recovery_required=True, recovery_reason=reason, recovery_error='')

def _generation_is_current(generation):
    with lock:
        return (generation == state.get('upload_generation') and
                not state.get('recovering') and not state.get('recovery_required'))

def _image_cache_paths(run_id):
    IMAGE_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    stem = str(int(run_id))
    return (IMAGE_CACHE_DIR / f'{stem}.json', IMAGE_CACHE_DIR / f'{stem}.source',
            IMAGE_CACHE_DIR / f'{stem}.output')

def _atomic_write(path, data):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_bytes(data)
    os.replace(temporary, path)

def persist_active_task(kind, run_id, generation):
    row={'kind':kind,'run_id':int(run_id),'generation':int(generation),
         'started_at':time.time(),'status':'active'}
    _atomic_write(ACTIVE_TASK_PATH,json.dumps(row,ensure_ascii=False).encode('utf-8'))

def clear_active_task(generation=None):
    try:
        if generation is not None and ACTIVE_TASK_PATH.is_file():
            row=json.loads(ACTIVE_TASK_PATH.read_text(encoding='utf-8-sig'))
            if int(row.get('generation',-1))!=int(generation):
                return
        ACTIVE_TASK_PATH.unlink(missing_ok=True)
    except (OSError,ValueError,TypeError,json.JSONDecodeError) as ex:
        event('系统',f'活动任务记录清理失败：{ex}')

def restore_active_task():
    try:
        if not ACTIVE_TASK_PATH.is_file():
            return
        row=json.loads(ACTIVE_TASK_PATH.read_text(encoding='utf-8-sig'))
        with lock:
            state.update(recovery_required=True,
                         recovery_reason=f"控制台意外退出时，{row.get('kind','板端')}任务 #{row.get('run_id','?')} 尚未确认完成",
                         recovery_error='')
        event('系统','检测到上次控制台退出时仍有板端任务；恢复确认前已锁定新任务')
    except (OSError,ValueError,TypeError,json.JSONDecodeError) as ex:
        with lock:
            state.update(recovery_required=True,recovery_reason='活动任务记录无法读取',recovery_error=str(ex))

def persist_image_run():
    """Keep each run's source, ARM pixels, and metadata recoverable across restarts."""
    with lock:
        run_id = int(image_state.get('run_id', 0))
        if run_id <= 0:
            return
        snapshot = {k: copy.deepcopy(v) for k, v in image_state.items()
                    if k not in ('source_bytes', 'output_bytes')}
        source = bytes(image_state.get('source_bytes', b''))
        output = bytes(image_state.get('output_bytes', b''))
    try:
        meta_path, source_path, output_path = _image_cache_paths(run_id)
        if source:
            _atomic_write(source_path, source)
        if snapshot.get('status') == 'complete' and output:
            _atomic_write(output_path, output)
        snapshot['cache_saved_at'] = time.time()
        _atomic_write(meta_path, json.dumps(snapshot, ensure_ascii=False,
                                           separators=(',', ':')).encode('utf-8'))
        runs = sorted((int(path.stem), path) for path in IMAGE_CACHE_DIR.glob('*.json')
                      if path.stem.isdecimal())
        for old_id, old_meta in runs[:-20]:
            old_meta.unlink(missing_ok=True)
            old_meta.with_suffix('.source').unlink(missing_ok=True)
            old_meta.with_suffix('.output').unlink(missing_ok=True)
    except OSError as ex:
        event('系统', f'图像运行 #{run_id} 保存失败：{ex}')

def _read_cached_image(run_id):
    try:
        meta_path, source_path, output_path = _image_cache_paths(run_id)
        if not meta_path.is_file():
            return None
        metadata = json.loads(meta_path.read_text(encoding='utf-8-sig'))
        source = source_path.read_bytes() if source_path.is_file() else b''
        output = output_path.read_bytes() if output_path.is_file() else b''
        if len(source) > 2 * 1024 * 1024 or len(output) > 640 * 480 * 3:
            return None
        return {'metadata': metadata, 'source': source, 'output': output}
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return None

def restore_last_image_run():
    try:
        candidates = sorted((int(path.stem), path) for path in IMAGE_CACHE_DIR.glob('*.json')
                           if path.stem.isdecimal())
    except OSError:
        candidates = []
    if not candidates:
        return
    cached = _read_cached_image(candidates[-1][0])
    if not cached:
        return
    metadata = cached['metadata']
    with lock:
        image_state.update(metadata)
        image_state['source_bytes'] = cached['source']
        image_state['output_bytes'] = bytearray(cached['output'])
        if metadata.get('status') in ('queued', 'sending', 'receiving', 'processing', 'returning_results'):
            image_state.update(status='error', completed_at=time.time(),
                               message='控制台曾在任务运行期间重启；板端任务可能仍在运行。原图已保留，请恢复板卡后再选择下一项。')
            state.update(recovery_required=True,recovery_reason='控制台重启前图像任务未确认完成',recovery_error='')
        elif metadata.get('status') == 'complete':
            expected = int(metadata.get('output_bytes_expected', 0))
            if not expected or len(cached['output']) != expected:
                image_state.update(status='error', completed_at=time.time(),
                                   message='本地结果缓存不完整，已保留原图；请重新提交本次实验。')
    if image_state.get('status') == 'error':
        persist_image_run()

def _update_worker_health(record):
    """Turn a CPU1 stage that stops advancing into a recoverable task error."""
    try:
        # The board's connection bit can remain high after the desktop GATT
        # client has disappeared. The desktop client is the authority for
        # whether this computer needs to keep scanning.
        if int(record.get('ble_present', 0)) and not pc_ble.snapshot().get('connected', False):
            pc_ble.ensure_scanning()
    except (NameError, TypeError, ValueError):
        pass
    try:
        worker = int(record.get('image_worker_state', 0))
    except (TypeError, ValueError):
        worker = 0
    stage = str(record.get('image_diagnostic', '') or '')[:96]
    should_persist = False
    with lock:
        state['telemetry'] = record
        if worker != 2:
            state['image_worker_stage'] = stage
            state['image_worker_stage_since'] = 0
            return
        now = time.time()
        if stage != state.get('image_worker_stage') or not state.get('image_worker_stage_since'):
            state['image_worker_stage'] = stage
            state['image_worker_stage_since'] = now
            return
        if '解码' in stage or '缩放' in stage:
            limit = 90
        elif '推理' in stage or '模型' in stage:
            # CPU1 MobileNet/SSD on the Z7-20 can legitimately take several minutes.
            limit = 600
        else:
            limit = 120
        elapsed = now - float(state['image_worker_stage_since'])
        active = image_state.get('status') in ('queued', 'sending', 'receiving', 'processing', 'returning_results')
        if active and elapsed >= limit:
            image_state.update(
                status='error', completed_at=now,
                message=f'CPU1 在“{stage or "图像处理"}”阶段连续 {int(elapsed)} 秒没有进展。已保留原图；请点击“退出任务并恢复板卡”，确认板端重新上线后再选择下一项。')
            should_persist = True
    if should_persist:
        _mark_recovery_required(image_state.get('message'))
        persist_image_run()
        event('系统', f'图像运行 #{image_state.get("run_id", 0)} 因 CPU1 阶段超时停止等待')

def _fail_tasks_on_link_loss(now=None, force=False):
    """Fail active board jobs when the UART stays open but telemetry stops."""
    global audio_upload_error, image_upload_error
    now = time.time() if now is None else now
    should_persist = False
    became_stale = False
    with lock:
        last_seen = float(state.get('last_rx') or state.get('connected_since') or 0)
        if not last_seen or (not force and now - last_seen <= 3):
            return
        if not state.get('link_stale'):
            state.update(link_stale=True, error='板端串口数据已静默超过 3 秒')
            became_stale = True
        link_message = '板端串口数据中断（超过 3 秒无回传），本次任务已停止；确认板卡运行后可重新提交。'
        if state.get('recovering'):
            return
        active_audio = audio_state.get('status') in ACTIVE_AUDIO_STATES
        active_image = image_state.get('status') in ACTIVE_IMAGE_STATES
        if active_audio:
            audio_state.update(status='error', completed_at=now, message='串口数据中断，板端是否仍在运行无法确认。原音频已保留；请退出并恢复板卡后再选择下一项。')
            audio_upload_error = link_message
            audio_upload_failed.set()
            audio_upload_start.set()
            audio_upload_ready.set()
            audio_upload_chunk.set()
        if active_image:
            image_state.update(status='error', completed_at=now, message='串口数据中断，板端是否仍在运行无法确认。原图已保留；请退出并恢复板卡后再选择下一项。')
            image_upload_error = link_message
            image_upload_failed.set()
            image_upload_start.set()
            image_upload_ready.set()
            image_upload_chunk.set()
            should_persist = True
        if active_audio or active_image:
            state.update(recovery_required=True, recovery_reason=link_message, recovery_error='')
    if became_stale:
        event('系统', '板端串口状态超过 3 秒未更新；控制、上传和结果状态已标记为离线')
    if should_persist:
        persist_image_run()

def _require_fresh_board_link():
    with lock:
        last_seen = float(state.get('last_rx') or state.get('connected_since') or 0)
        if not state.get('connected') or not last_seen or time.time() - last_seen > 3 or state.get('link_stale'):
            raise RuntimeError('板端状态数据已过期，请确认开发板运行并收到实时串口状态')

def _raise_if_upload_failed(failed_event, error_getter, label, generation=None):
    if generation is not None and not _generation_is_current(generation):
        raise RuntimeError('本次上传已退出；等待板卡恢复完成')
    if failed_event.is_set():
        with lock:
            message = error_getter()
        raise RuntimeError(message or f'{label}链路已中断')
    _require_fresh_board_link()

def reader():
    global port, audio_upload_error, audio_upload_count, image_upload_error, image_upload_count
    pending = b''
    while True:
        try:
            if port is None:
                choices = [p.device for p in list_ports.comports() if p.vid == 0x0403 and p.pid == 0x6010]
                device = 'COM13' if 'COM13' in choices else (choices[0] if len(choices) == 1 else 'COM13')
                port = serial.Serial(device, 921600, timeout=0.1, write_timeout=1)
                with lock: state.update(connected=True, port=device, connected_since=time.time())
                event('系统', f'{device} 已连接 · 921600 / 8N1')
            data = port.read(port.in_waiting or 1)
            _fail_tasks_on_link_loss()
            if data:
                pending += data
                now = time.time()
                with lock:
                    previous = float(state.get('last_rx') or state.get('connected_since') or 0)
                    recovered = bool(state.get('link_stale')) or (previous and now - previous > 3)
                    state.update(last_rx=now, link_stale=False, error='')
                if recovered:
                    event('系统', '已重新收到板端实时串口数据，可以继续操作')
                while b'\n' in pending:
                    raw, pending = pending.split(b'\n', 1)
                    line = raw.decode('utf-8', 'replace').strip('\r\x00')
                    if not line.strip(): continue
                    try:
                        record = json.loads(line)
                    except json.JSONDecodeError:
                        event('接收', line)
                        continue
                    if isinstance(record, dict) and record.get('kind') == 'audio' and record.get('event') == 'frame':
                        event('接收', f"音频时频帧 {record.get('index', 0)} · {record.get('time_ms', 0)} ms · ARM 频谱已回传")
                    elif isinstance(record, dict) and record.get('kind') == 'audio' and record.get('event') == 'playback_chunk':
                        event('接收', f"处理后试听数据块 {record.get('index', 0)} · {record.get('bytes', 0)} 字节 · ARM 已回传")
                    elif isinstance(record, dict) and record.get('kind') == 'image' and record.get('event') == 'pixels':
                        event('接收', f"板端图像结果块 {record.get('index', 0)} · {record.get('bytes', 0)} 字节")
                    else:
                        event('接收', line)
                    with lock:
                        discard_task_event = bool(state.get('recovering') and isinstance(record, dict) and record.get('kind') in ('audio', 'image'))
                    if discard_task_event:
                        continue
                    try:
                        if isinstance(record, dict) and record.get('kind') == 'state':
                            _update_worker_health(record)
                        elif isinstance(record, dict) and record.get('kind') == 'audio':
                            audio_event = record.get('event')
                            with lock:
                                if audio_event == 'led_state':
                                    audio_state['led_state'] = record.get('state', 'idle')
                                elif audio_event == 'upload_wait_header':
                                    audio_state.update(status='receiving', progress=0, message='板端 ARM 已就绪，正在接收文件。', result=None, waveform=None, spectrum=None, frames=[], playback=None)
                                    audio_upload_start.set()
                                elif audio_event == 'upload_ready':
                                    audio_upload_ready.set()
                                elif audio_event == 'upload_chunk':
                                    audio_upload_count = int(record.get('received', 0))
                                    audio_upload_chunk.set()
                                    audio_state['progress'] = min(99, audio_upload_count * 100 // max(1, audio_state['bytes']))
                                    audio_state['status'] = 'sending'
                                    audio_state['message'] = f'板端已确认 {audio_upload_count} / {audio_state["bytes"]} 字节'
                                elif audio_event == 'processing':
                                    audio_state.update(status='processing', progress=100, message='文件已到板；ARM 正在解码和分析。')
                                elif audio_event == 'result':
                                    audio_state.update(status='returning_results', result=record, message='ARM 运算完成，正在回传本次图表与指标。')
                                elif audio_event == 'waveform':
                                    audio_state['waveform'] = record
                                elif audio_event == 'spectrum':
                                    audio_state['spectrum'] = record
                                elif audio_event == 'frame':
                                    if len(audio_state['frames']) < 2048:
                                        audio_state['frames'].append(record)
                                elif audio_event == 'playback_start':
                                    audio_state['playback'] = {
                                        'sample_rate_hz': int(record.get('sample_rate_hz', 16000)),
                                        'channels': int(record.get('channels', 1)),
                                        'sample_bits': int(record.get('sample_bits', 16)),
                                        'samples': int(record.get('samples', 0)),
                                        'bytes': int(record.get('bytes', 0)),
                                        'duration_ms': int(record.get('duration_ms', 0)),
                                        'chunks_expected': int(record.get('chunks', 0)),
                                        'chunks': [],
                                        'received_bytes': 0,
                                    }
                                    audio_state.update(status='returning_audio', progress=0, message='分析图表已回传；正在从开发板接收处理后的试听音频。')
                                elif audio_event == 'playback_chunk':
                                    playback = audio_state.get('playback')
                                    chunk = record.get('data', '')
                                    if playback is not None and isinstance(chunk, str):
                                        playback['chunks'].append(chunk)
                                        playback['received_bytes'] += int(record.get('bytes', 0))
                                        total = max(1, playback['bytes'])
                                        audio_state.update(status='returning_audio', progress=min(99, playback['received_bytes'] * 100 // total), message=f"正在回传处理后音频：{playback['received_bytes']} / {playback['bytes']} 字节")
                                elif audio_event == 'playback_sent':
                                    if audio_state.get('playback') is not None:
                                        audio_state['playback']['sent_bytes'] = int(record.get('bytes', 0))
                                elif audio_event == 'done':
                                    audio_state.update(status='complete', progress=100, message='板端 ARM 分析完成。', completed_at=time.time())
                                    clear_active_task(state.get('upload_generation'))
                                elif audio_event == 'error':
                                    previous_status=audio_state.get('status')
                                    audio_state.update(status='error', message=record.get('message','板端处理失败。'))
                                    audio_upload_error = record.get('message','板端处理失败。')
                                    audio_upload_failed.set()
                                    if previous_status in ('processing','returning_results','returning_audio'):
                                        state.update(recovery_required=True,recovery_reason='音频处理在板端异常结束，需要重载固件确认任务已退出',recovery_error='')
                                    else:
                                        clear_active_task(state.get('upload_generation'))
                        elif isinstance(record, dict) and record.get('kind') == 'image':
                            image_event = record.get('event')
                            if 'run_id' in record:
                                with lock: current_run = int(image_state.get('run_id', 0))
                                try:
                                    event_run = int(record.get('run_id', -1))
                                except (TypeError, ValueError):
                                    continue
                                if event_run != current_run:
                                    continue
                            with lock:
                                if image_event == 'led_state':
                                    image_state['led_state'] = record.get('state', 'idle')
                                elif image_event == 'upload_wait_header':
                                    image_state.update(status='receiving', progress=0, message='板端 ARM 已就绪，正在接收原图。', result=None, output_bytes=bytearray(), output_bytes_expected=0)
                                    image_upload_start.set()
                                elif image_event == 'upload_ready':
                                    image_upload_ready.set()
                                elif image_event == 'upload_chunk':
                                    image_upload_count = int(record.get('received', 0))
                                    image_upload_chunk.set()
                                    image_state.update(progress=min(99, image_upload_count * 100 // max(1, image_state['bytes'])), status='sending', message=f"板端已确认 {image_upload_count} / {image_state['bytes']} 字节")
                                elif image_event == 'processing':
                                    image_state.update(status='processing', progress=100, processing_started_at=time.time(), message='原图已到板；ARM 正在解码、缩放与处理。')
                                elif image_event == 'result':
                                    record['firmware_version']=int((state.get('telemetry') or {}).get('firmware_version',0))
                                    record['histogram_input']=[0]*256
                                    record['histogram_output']=[0]*256
                                    image_state.update(status='returning_results', result=record, message='板端算法完成，正在回传本次结果图与指标。')
                                elif image_event == 'histogram':
                                    result=image_state.get('result')
                                    if result and int(record.get('run_id', -1)) == int(image_state.get('run_id', -2)):
                                        start=int(record.get('start',0))
                                        for i,value in enumerate(record.get('input',[])):
                                            if 0<=start+i<256: result['histogram_input'][start+i]=int(value)
                                        for i,value in enumerate(record.get('output',[])):
                                            if 0<=start+i<256: result['histogram_output'][start+i]=int(value)
                                elif image_event == 'pixels_start':
                                    expected = int(record.get('bytes', 0))
                                    width = int(record.get('width', 0))
                                    height = int(record.get('height', 0))
                                    channels = int(record.get('channels', 3 if record.get('encoding') == 'rgb24' else 1))
                                    if width < 1 or width > 640 or height < 1 or height > 480 or channels not in (1, 3) or expected != width * height * channels:
                                        image_state.update(status='error', message='ARM 结果图尺寸或数据长度无效。')
                                        state.update(recovery_required=True,recovery_reason='ARM 图像结果尺寸或传输长度异常',recovery_error='')
                                        image_upload_error = image_state['message']
                                        image_upload_failed.set()
                                    else:
                                        image_state['output_bytes_expected'] = expected
                                        image_state['output_width'] = width
                                        image_state['output_height'] = height
                                        image_state['output_channels'] = channels
                                        image_state['output_bytes'] = bytearray()
                                        image_state.update(status='returning_results', progress=0, result_transfer_started_at=time.time(), message='正在从开发板接收结果像素。')
                                elif image_event == 'pixels':
                                    if int(record.get('run_id', -1)) == int(image_state.get('run_id', -2)):
                                        piece = base64.b64decode(record.get('data', ''), validate=True)
                                        total = int(image_state.get('output_bytes_expected', 0))
                                        if not total or len(image_state['output_bytes']) + len(piece) > total:
                                            image_state.update(status='error', message='ARM 回传结果超出声明长度，已停止接收。')
                                            state.update(recovery_required=True,recovery_reason='ARM 图像结果块超出声明长度',recovery_error='')
                                            image_upload_error = image_state['message']
                                            image_upload_failed.set()
                                        else:
                                            image_state['output_bytes'].extend(piece)
                                            image_state.update(progress=min(99, len(image_state['output_bytes']) * 100 // total), message=f"正在回传 ARM 结果：{len(image_state['output_bytes'])} / {total} 字节")
                                elif image_event == 'done':
                                    expected = int(image_state.get('output_bytes_expected', 0))
                                    received = len(image_state.get('output_bytes', b''))
                                    if not expected or expected != received:
                                        image_state.update(status='error', message=f'板端结果长度不完整：{received} / {expected} 字节')
                                        state.update(recovery_required=True,recovery_reason='ARM 图像结果未完整回传',recovery_error='')
                                    else:
                                        image_state.update(status='complete', progress=100, message='本次板端图像处理已完成。', completed_at=time.time())
                                        clear_active_task(state.get('upload_generation'))
                                elif image_event == 'error':
                                    image_state.update(status='error', message=record.get('message','板端图像处理失败。'))
                                    image_upload_error = record.get('message','板端图像处理失败。')
                                    image_upload_failed.set()
                                    image_upload_ready.set()
                                    clear_active_task(state.get('upload_generation'))
                            if image_event in ('upload_wait_header', 'processing', 'pixels_start', 'done', 'error'):
                                persist_image_run()
                    except json.JSONDecodeError: pass
                    except (TypeError, ValueError, KeyError) as ex:
                        event('接收', f'忽略格式无效的板端数据：{ex}')
                    except binascii.Error as ex:
                        with lock:
                            image_state.update(status='error',message=f'板端像素块解码失败：{ex}')
                            state.update(recovery_required=True,recovery_reason='板端回传的图像像素块无法解码',recovery_error='')
                            image_upload_error=str(ex)
                            image_upload_failed.set()
                if len(pending) > 65536:
                    event('接收', pending.decode('utf-8', 'replace')); pending = b''
        except (serial.SerialException, OSError) as ex:
            with lock: state.update(connected=False, link_stale=True, error=str(ex))
            _fail_tasks_on_link_loss(force=True)
            if port:
                try: port.close()
                except Exception: pass
            port = None; pending = b''
            time.sleep(2)

def recover_board():
    global audio_upload_error, image_upload_error
    recovery_started_at = time.time()
    ok = False
    try:
        profiles={'monitor': ROOT.parent / 'sensor_project' / 'RUN_MONITOR.ps1', 'sensor': ROOT.parent / 'sensor_project' / 'RUN_SENSOR.ps1'}
        key=json.loads((ROOT/'active_profile.json').read_text(encoding='utf-8-sig')).get('profile','monitor')
        script=profiles[key]
        event('系统','正在重载板端程序以安全退出当前任务；等待新启动状态确认')
        with (ROOT/'recovery.log').open('w',encoding='utf-8') as output:
            powershell = os.environ.get('ZYBO_POWERSHELL') or shutil.which('pwsh') or shutil.which('powershell')
            if not powershell:
                raise RuntimeError('PowerShell executable was not found')
            child=subprocess.run([powershell,'-NoProfile','-File',str(script)],stdout=output,stderr=subprocess.STDOUT,timeout=120,creationflags=subprocess.CREATE_NO_WINDOW)
        if child.returncode: raise RuntimeError(f'下载失败，详情见 recovery.log（退出码 {child.returncode}）')
        script_finished_at=time.time()
        deadline=script_finished_at+35
        while time.time()<deadline:
            with lock:
                telemetry=copy.deepcopy(state.get('telemetry') or {})
                last_rx=float(state.get('last_rx') or 0)
                connected=bool(state.get('connected'))
            fresh=connected and last_rx>script_finished_at and time.time()-last_rx<3
            if key=='sensor':
                board_ready=(int(telemetry.get('firmware_version',0))>=50 and
                             int(telemetry.get('image_cpu1_ready',0))==1 and
                             int(telemetry.get('image_worker_state',0))==5)
            else:
                board_ready=bool(telemetry)
            if fresh and board_ready:
                ok=True
                break
            time.sleep(.2)
        if not ok:
            raise RuntimeError('固件已下载，但未在 35 秒内确认板卡重新上线和图像核空闲。检查供电、JTAG 与串口后可重试恢复。')
        with lock:
            state.update(recovering=False,recovery_required=False,recovery_reason='',recovery_error='',link_stale=False,error='')
            for task in (audio_state,image_state):
                if task.get('status')=='recovering':
                    task.update(status='cancelled',completed_at=time.time(),progress=0,
                                message='已退出旧任务并确认板端重新启动。原始文件仍保留，可选择新文件或重新运行。')
            audio_upload_error=''
            image_upload_error=''
            audio_upload_failed.clear(); image_upload_failed.clear()
            audio_upload_start.clear(); audio_upload_ready.clear(); audio_upload_chunk.clear()
            image_upload_start.clear(); image_upload_ready.clear(); image_upload_chunk.clear()
        clear_active_task()
        persist_image_run()
        event('系统','板端已重新启动，实时状态恢复，CPU1 图像核空闲；现在可以重新选择功能')
    except Exception as ex:
        message=str(ex)
        with lock:
            state.update(recovering=False,recovery_required=True,recovery_error=message,recovery_reason='板卡恢复未完成')
            for task in (audio_state,image_state):
                if task.get('status')=='recovering':
                    task.update(status='error',completed_at=time.time(),message='板卡恢复尚未确认完成；当前任务已退出，请检查连接后重试恢复。'+message)
            audio_upload_error=message
            image_upload_error=message
        persist_image_run()
        event('系统','板卡恢复未完成：'+message)

def send_audio_payload(payload, filename, filter_mode, noise_start_ms=0, noise_end_ms=0, generation=0):
    global port, audio_upload_error, audio_upload_count
    try:
        with serial_tx_lock:
            if not _generation_is_current(generation):
                raise RuntimeError('板卡正在恢复；本次上传已退出')
            with lock:
                active_port = port
                if active_port is None or not active_port.is_open:
                    raise RuntimeError('串口未连接，无法把文件送到板端')
                audio_upload_error = ''
            audio_upload_start.clear()
            audio_upload_ready.clear()
            audio_upload_chunk.clear()
            audio_upload_failed.clear()
            active_port.write(b'Z')
            active_port.flush()
            if not audio_upload_start.wait(3):
                _raise_if_upload_failed(audio_upload_failed, lambda: audio_upload_error, '音频', generation)
                raise RuntimeError('板端未响应音频上传启动命令')
            _raise_if_upload_failed(audio_upload_failed, lambda: audio_upload_error, '音频', generation)
            crc = zlib.crc32(payload) & 0xffffffff
            header = b'WAV1' + struct.pack('<IBIII', len(payload), filter_mode, crc,
                                           noise_start_ms, noise_end_ms)
            active_port.write(header)
            active_port.flush()
            if not audio_upload_ready.wait(3):
                _raise_if_upload_failed(audio_upload_failed, lambda: audio_upload_error, '音频', generation)
                with lock: board_error = audio_upload_error
                if board_error: raise RuntimeError(f'板端拒绝文件头：{board_error}')
                raise RuntimeError('板端未确认文件长度与校验信息')
            _raise_if_upload_failed(audio_upload_failed, lambda: audio_upload_error, '音频', generation)
            sent = 0
            while sent < len(payload):
                if not _generation_is_current(generation):
                    raise RuntimeError('本次上传已退出；等待板卡恢复完成')
                # The firmware acknowledges each 512-byte boundary. Sending
                # 2 KiB at once lets the first ACK wake this wait prematurely.
                chunk = payload[sent:sent+512]
                audio_upload_count = sent
                audio_upload_chunk.clear()
                active_port.write(chunk)
                active_port.flush()
                if not audio_upload_chunk.wait(2):
                    _raise_if_upload_failed(audio_upload_failed, lambda: audio_upload_error, '音频', generation)
                    with lock: board_error = audio_upload_error
                    if board_error: raise RuntimeError(f'板端接收失败：{board_error}')
                    raise RuntimeError(f'板端未确认第 {sent + len(chunk)} 字节')
                _raise_if_upload_failed(audio_upload_failed, lambda: audio_upload_error, '音频', generation)
                if audio_upload_count != sent + len(chunk):
                    raise RuntimeError(f'板端收件位置不一致：期望 {sent + len(chunk)}，实际 {audio_upload_count}')
                sent += len(chunk)
                with lock:
                    audio_state['progress'] = min(99, sent * 100 // len(payload))
                    audio_state['status'] = 'sending'
                    audio_state['message'] = f'电脑仅在转发原文件：{sent} / {len(payload)} 字节'
            active_port.flush()
        with lock:
            if audio_state['status'] == 'sending':
                audio_state.update(status='waiting_board', progress=100, message='文件已传完，等待 ARM 解码和分析。')
        event('系统', f'音频原文件已转发到 Zybo ARM：{filename} ({len(payload)} bytes)')
    except Exception as ex:
        with lock:
            recovering = bool(state.get('recovering'))
            known_board_error = bool(audio_upload_error)
            recovery_required = bool(state.get('recovery_required'))
            if not recovering and audio_state.get('status') not in ('recovering','cancelled'):
                audio_state.update(status='error', completed_at=time.time(), message=str(ex))
        if not recovering and not known_board_error and _generation_is_current(generation):
            _mark_recovery_required(f'音频传输状态不明确：{ex}')
        elif known_board_error and not recovery_required:
            clear_active_task(generation)
        event('系统', f'音频上传失败：{ex}')

def send_image_payload(payload, filename, run_id, algorithm, strength, threshold, generation=0):
    global port, image_upload_error, image_upload_count
    try:
        with serial_tx_lock:
            if not _generation_is_current(generation):
                raise RuntimeError('板卡正在恢复；本次上传已退出')
            with lock:
                active_port = port
                if active_port is None or not active_port.is_open:
                    raise RuntimeError('串口未连接，无法把图像送到板端')
                image_upload_error = ''
            image_upload_start.clear()
            image_upload_ready.clear()
            image_upload_chunk.clear()
            image_upload_failed.clear()
            active_port.write(b'R')
            active_port.flush()
            if not image_upload_start.wait(3):
                _raise_if_upload_failed(image_upload_failed, lambda: image_upload_error, '图像', generation)
                raise RuntimeError('板端未响应图像上传启动命令')
            _raise_if_upload_failed(image_upload_failed, lambda: image_upload_error, '图像', generation)
            header = (b'IMG1' + struct.pack('<IIBBBI', len(payload), run_id,
                      algorithm, strength, threshold, zlib.crc32(payload) & 0xffffffff))
            active_port.write(header)
            active_port.flush()
            if not image_upload_ready.wait(3):
                _raise_if_upload_failed(image_upload_failed, lambda: image_upload_error, '图像', generation)
                with lock: board_error = image_upload_error
                if board_error: raise RuntimeError(f'板端拒绝图像帧：{board_error}')
                raise RuntimeError('板端未确认图像长度与校验信息')
            _raise_if_upload_failed(image_upload_failed, lambda: image_upload_error, '图像', generation)
            if image_upload_failed.is_set():
                with lock: board_error = image_upload_error
                raise RuntimeError(f'板端拒绝图像帧：{board_error or "参数或校验错误"}')
            sent = 0
            while sent < len(payload):
                if not _generation_is_current(generation):
                    raise RuntimeError('本次上传已退出；等待板卡恢复完成')
                chunk = payload[sent:sent+8192]
                image_upload_count = sent
                image_upload_chunk.clear()
                active_port.write(chunk)
                active_port.flush()
                if not image_upload_chunk.wait(3):
                    _raise_if_upload_failed(image_upload_failed, lambda: image_upload_error, '图像', generation)
                    with lock: board_error = image_upload_error
                    if board_error: raise RuntimeError(f'板端接收失败：{board_error}')
                    raise RuntimeError(f'板端未确认第 {sent + len(chunk)} 字节')
                _raise_if_upload_failed(image_upload_failed, lambda: image_upload_error, '图像', generation)
                if image_upload_count != sent + len(chunk):
                    raise RuntimeError(f'板端收件位置不一致：期望 {sent + len(chunk)}，实际 {image_upload_count}')
                sent += len(chunk)
                with lock:
                    image_state.update(progress=min(99, sent * 100 // len(payload)), status='sending', message=f'电脑仅在转发原图：{sent} / {len(payload)} 字节')
            active_port.flush()
        with lock:
            if image_state['status'] == 'sending':
                image_state.update(status='processing', progress=100, message='文件已传完，等待 ARM 解码和处理。')
        event('系统', f'原图已转发到 Zybo ARM：{filename} ({len(payload)} bytes)')
    except Exception as ex:
        with lock:
            recovering = bool(state.get('recovering'))
            known_board_error = bool(image_upload_error)
            recovery_required = bool(state.get('recovery_required'))
            if not recovering and image_state.get('status') not in ('recovering','cancelled'):
                image_state.update(status='error', completed_at=time.time(), message=str(ex))
        if not recovering and not known_board_error and _generation_is_current(generation):
            _mark_recovery_required(f'图像传输状态不明确：{ex}')
        elif known_board_error and not recovery_required:
            clear_active_task(generation)
        persist_image_run()
        event('系统', f'图像上传失败：{ex}')

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args): pass
    def reply(self, value, status=200):
        data = json.dumps(value, ensure_ascii=False).encode()
        self.send_response(status); self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store'); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        parsed=urlsplit(self.path)
        summary_audio = parsed.path == '/api/audio/status' and parsed.query == 'summary=1'
        image_query = parse_qs(parsed.query)
        self.path=parsed.path
        if self.path == '/api/state':
            compact_state = image_query.get('compact', ['0'])[0] == '1'
            since_id = None
            if compact_state and 'since' in image_query:
                try: since_id = max(0, int(image_query['since'][0]))
                except (TypeError, ValueError): since_id = 0
            with lock:
                audio_summary=copy.deepcopy(audio_state)
                audio_summary.update(waveform=None,spectrum=None,frames=[],playback=None)
                image_summary={k:v for k,v in image_state.items() if k not in ('output_bytes','source_bytes')}
                event_rows=list(events)
                if compact_state:
                    event_rows=[] if since_id is None else [row for row in event_rows if row['id'] > since_id]
                    if len(event_rows) > 220: event_rows=event_rows[-220:]
                result = dict(state, events=event_rows, audio=audio_summary, image=image_summary, rx_age=(time.time() - state['last_rx']) if state['last_rx'] else None)
            result['pc_ble']=pc_ble.snapshot()
            result['api_version']=6
            self.reply(result)
        elif self.path in ('/', '/index.html'):
            data=(ROOT / 'index.html').read_bytes()
            self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(data)
        elif self.path in ('/audio', '/audio.html'):
            data=(ROOT / 'audio.html').read_bytes()
            self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(data)
        elif self.path in ('/image', '/image.html'):
            data=(ROOT / 'image.html').read_bytes()
            self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(data)
        elif self.path == '/project':
            data=(ROOT / 'project.html').read_bytes()
            self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.end_headers(); self.wfile.write(data)
        elif self.path == '/wiring':
            data=(ROOT / 'wiring.html').read_bytes()
            self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.end_headers(); self.wfile.write(data)
        elif self.path == '/console-theme.css':
            data=(ROOT / 'console-theme.css').read_bytes()
            self.send_response(200); self.send_header('Content-Type','text/css; charset=utf-8'); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(data)
        elif self.path == '/console-shell.js':
            data=(ROOT / 'console-shell.js').read_bytes()
            self.send_response(200); self.send_header('Content-Type','text/javascript; charset=utf-8'); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(data)
        elif self.path == '/api/export':
            with lock: data=json.dumps(list(events),ensure_ascii=False,indent=2).encode()
            self.send_response(200); self.send_header('Content-Type','application/json; charset=utf-8')
            self.send_header('Content-Disposition','attachment; filename="zybo_recent_serial.json"'); self.end_headers(); self.wfile.write(data)
        elif self.path == '/api/audio/status':
            with lock:
                result = copy.deepcopy(audio_state)
                if summary_audio: result.update(waveform=None,spectrum=None,frames=[],playback=None)
                result['board'] = copy.deepcopy(state['telemetry'])
                result['board_connected'] = state['connected']
                result['board_port'] = state['port']
                result['rx_age'] = (time.time() - state['last_rx']) if state['last_rx'] else None
                result['recovering'] = state['recovering']
                result['recovery_required'] = state['recovery_required']
                result['recovery_reason'] = state['recovery_reason']
                result['recovery_error'] = state['recovery_error']
                result['api_version'] = 6
            self.reply(result)
        elif self.path == '/api/audio/samples':
            catalog=[]
            for item in AUDIO_DEMO_CATALOG:
                sample_path=AUDIO_SAMPLE_DIR / item['name']
                reference_path=AUDIO_SAMPLE_DIR / item['reference'] if item.get('reference') else None
                if sample_path.is_file() and sample_path.stat().st_size <= 2 * 1024 * 1024:
                    catalog.append({**item,'bytes':sample_path.stat().st_size,
                                    'reference_available':bool(reference_path and reference_path.is_file() and reference_path.stat().st_size <= 2 * 1024 * 1024)})
            self.reply({'samples':catalog})
        elif self.path == '/api/audio/sample':
            name=parse_qs(parsed.query).get('name',[''])[0]
            allowed=AUDIO_SAMPLE_FILES.get(name)
            if not allowed:
                return self.reply({'error':'演示音频不存在'},404)
            sample_path=AUDIO_SAMPLE_DIR / allowed
            try:
                data=sample_path.read_bytes()
            except OSError:
                return self.reply({'error':'演示音频暂不可读'},404)
            if not data or len(data)>2*1024*1024:
                return self.reply({'error':'演示音频大小无效'},413)
            mime='audio/mpeg' if sample_path.suffix.lower()=='.mp3' else 'audio/wav'
            self.send_response(200); self.send_header('Content-Type',mime); self.send_header('Cache-Control','no-store'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
        elif self.path == '/api/image/status':
            requested = int(image_query.get('run_id', ['0'])[0] or 0)
            with lock:
                current_run = int(image_state.get('run_id', 0))
                result={k:v for k,v in image_state.items() if k not in ('output_bytes','source_bytes')}
                result['recovering'] = state['recovering']
                result['recovery_required'] = state['recovery_required']
                result['recovery_reason'] = state['recovery_reason']
                result['recovery_error'] = state['recovery_error']
            if requested and requested != current_run:
                cached = _read_cached_image(requested)
                if cached:
                    result = cached['metadata']
                else:
                    result.update(status='idle',run_id=requested,result=None,progress=0,message='没有找到这次运行的本地记录。',output_bytes_expected=0,output_width=0,output_height=0)
            with lock:
                result['board_connected']=state['connected']
                result['board_port']=state['port']
                result['rx_age']=(time.time()-state['last_rx']) if state['last_rx'] else None
                result['recovering']=state['recovering']
                result['recovery_required']=state['recovery_required']
                result['recovery_reason']=state['recovery_reason']
                result['recovery_error']=state['recovery_error']
                result['api_version']=6
            self.reply(result)
        elif self.path == '/api/image/samples':
            catalog=[]
            for item in IMAGE_DEMO_CATALOG:
                sample_path=IMAGE_SAMPLE_DIR / item['name']
                if sample_path.is_file() and sample_path.stat().st_size <= 2 * 1024 * 1024:
                    catalog.append({**item,'bytes':sample_path.stat().st_size})
            self.reply({'samples':catalog,'counts':{
                'total':len(catalog),
                'originals':sum(1 for item in catalog if item.get('kind')=='original'),
                'derived':sum(1 for item in catalog if item.get('kind')=='derived'),
                'archives':sum(1 for item in catalog if item.get('kind')=='archive'),
            }})
        elif self.path == '/api/image/sample':
            name=image_query.get('name',[''])[0]
            item=IMAGE_SAMPLE_BY_NAME.get(name)
            if not item:
                return self.reply({'error':'演示图片不存在'},404)
            sample_path=IMAGE_SAMPLE_DIR / item['name']
            try:
                data=sample_path.read_bytes()
            except OSError:
                return self.reply({'error':'演示图片暂不可读'},404)
            if not data or len(data)>2*1024*1024:
                return self.reply({'error':'演示图片大小无效'},413)
            mime={'.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.bmp':'image/bmp'}.get(sample_path.suffix.lower(),'application/octet-stream')
            self.send_response(200); self.send_header('Content-Type',mime); self.send_header('Cache-Control','no-store'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
        elif self.path == '/api/image/source':
            requested = int(image_query.get('run_id', ['0'])[0] or 0)
            with lock:
                is_current = requested == int(image_state.get('run_id', 0))
                data = bytes(image_state.get('source_bytes', b'')) if is_current else b''
                filename = image_state.get('filename', 'image') if is_current else 'image'
            if not data:
                cached = _read_cached_image(requested) if requested > 0 else None
                if cached:
                    data = cached['source']
                    filename = cached['metadata'].get('filename', 'image')
            if not data:
                return self.reply({'error':'当前运行没有可恢复的原图'},404)
            mime = {'.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.bmp':'image/bmp'}.get(Path(filename).suffix.lower(),'application/octet-stream')
            self.send_response(200); self.send_header('Content-Type',mime); self.send_header('Cache-Control','no-store'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
        elif self.path == '/api/image/output':
            requested = int(image_query.get('run_id', ['0'])[0] or 0)
            with lock:
                is_current = requested == int(image_state.get('run_id', 0))
                complete = image_state.get('status') == 'complete'
                data=bytes(image_state.get('output_bytes', b'')) if is_current and complete else b''
                width=int(image_state.get('output_width',0)) if is_current else 0
                height=int(image_state.get('output_height',0)) if is_current else 0
                channels=int(image_state.get('output_channels',1)) if is_current else 1
            if not data:
                cached = _read_cached_image(requested) if requested > 0 else None
                if cached and cached['metadata'].get('status') == 'complete':
                    data = cached['output']
                    width=int(cached['metadata'].get('output_width',0))
                    height=int(cached['metadata'].get('output_height',0))
                    channels=int(cached['metadata'].get('output_channels',1))
            if not data or len(data) != width * height * channels:
                return self.reply({'error':'当前运行尚无完整的板端结果'},409)
            self.send_response(200); self.send_header('Content-Type','application/octet-stream'); self.send_header('Cache-Control','no-store')
            self.send_header('X-Image-Width',str(width)); self.send_header('X-Image-Height',str(height)); self.send_header('X-Image-Channels',str(channels)); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
        else: self.reply({'error':'不存在'},404)
    def do_POST(self):
        global audio_upload_error, image_upload_error
        origin = self.headers.get('Origin')
        if origin and origin not in ('http://127.0.0.1:8765', 'http://localhost:8765'): return self.reply({'error':'来源无效'},403)
        if self.path == '/api/ble/connect':
            # Scanning is persistent; the board's radio configuration is never reset here.
            pc_ble.connect();return self.reply({'started':True})
        if self.path == '/api/ble/stop':
            pc_ble.stop();return self.reply({'stopped':True})
        if self.path == '/api/ble/send':
            try:
                size=int(self.headers.get('Content-Length','0'))
                if size<1 or size>128:raise ValueError('命令过长')
                pc_ble.send(json.loads(self.rfile.read(size)).get('command',''))
                return self.reply({'sent':True,'note':'通过电脑蓝牙发送，等待无线 ACK'})
            except (ValueError,TypeError) as ex:return self.reply({'error':str(ex)},400)
        if self.path == '/api/recover':
            with lock:
                if state['recovering']: return self.reply({'error':'正在恢复，请稍候'},409)
                state.update(recovering=True,recovery_required=True,recovery_error='',
                             recovery_reason='正在重载固件，退出当前板端任务',
                             upload_generation=int(state.get('upload_generation',0))+1)
                for task in (audio_state,image_state):
                    if task.get('status') in ACTIVE_AUDIO_STATES or task.get('status') in ACTIVE_IMAGE_STATES:
                        task.update(status='recovering',completed_at=None,
                                    message='正在退出当前任务并重启板端。确认新固件上线前不会接收下一项。')
                audio_upload_error='用户请求退出当前任务并恢复板卡'
                image_upload_error='用户请求退出当前任务并恢复板卡'
                audio_upload_failed.set(); image_upload_failed.set()
                audio_upload_start.set(); audio_upload_ready.set(); audio_upload_chunk.set()
                image_upload_start.set(); image_upload_ready.set(); image_upload_chunk.set()
            threading.Thread(target=recover_board,daemon=True).start()
            event('系统','已请求退出当前任务并重载板端固件')
            return self.reply({'started':True,'message':'板端重载已启动；新功能会在重新上线确认后开放'})
        if urlsplit(self.path).path == '/api/audio/upload':
            try:
                size = int(self.headers.get('Content-Length','0'))
                mode = int(self.headers.get('X-Filter-Mode','0'))
                noise_start_ms = int(self.headers.get('X-Noise-Start-Ms','0'))
                noise_end_ms = int(self.headers.get('X-Noise-End-Ms','0'))
                filename = unquote(self.headers.get('X-Audio-Name','audio file'))
                if size < 4 or size > 2*1024*1024: raise ValueError('WAV/MP3 文件需为 4 字节至 2 MiB')
                if mode < 0 or mode > 13: raise ValueError('滤波模式无效')
                if mode == 8:
                    if noise_start_ms < 0 or noise_end_ms - noise_start_ms < 100 or noise_end_ms > 30000:
                        raise ValueError('噪声参考片段需为 100 ms 至 30 s，并且起点早于终点')
                else:
                    noise_start_ms = 0
                    noise_end_ms = 0
                payload = self.rfile.read(size)
                if len(payload) != size: raise ValueError('上传数据长度不完整')
                with lock:
                    if state['recovering'] or state['recovery_required']: return self.reply({'error':state.get('recovery_error') or '板卡尚未恢复确认；请先恢复板卡再上传'},409)
                    if port is None or not port.is_open: return self.reply({'error':'串口未连接'},409)
                    if not state.get('last_rx') or state.get('link_stale') or time.time()-state['last_rx']>3:
                        return self.reply({'error':'板卡状态数据已过期，请确认开发板运行并收到实时串口状态'},409)
                    if audio_state['status'] in ACTIVE_AUDIO_STATES or image_state['status'] in ACTIVE_IMAGE_STATES:
                        return self.reply({'error':'上一份音频或图像任务仍在运行'},409)
                    state['upload_generation'] += 1
                    generation=state['upload_generation']
                    run_id = int(audio_state.get('run_id', 0)) + 1
                    audio_state.update(run_id=run_id,started_at=time.time(),completed_at=None,status='queued',filename=filename,bytes=size,progress=0,message='准备把原文件发送到板端 ARM。',result=None,waveform=None,spectrum=None,frames=[],playback=None)
                try:
                    persist_active_task('audio',run_id,generation)
                except OSError as ex:
                    with lock:
                        audio_state.update(status='error',completed_at=time.time(),message='无法保存任务恢复记录，已阻止上传：'+str(ex))
                        state.update(recovery_required=True,recovery_reason='无法保存活动任务恢复记录',recovery_error=str(ex))
                    return self.reply({'error':'无法保存恢复记录，未启动音频任务：'+str(ex)},500)
                threading.Thread(target=send_audio_payload,
                                 args=(payload,filename,mode,noise_start_ms,noise_end_ms,generation),
                                 daemon=True).start()
                return self.reply({'started':True,'run_id':run_id,'processor':'Zynq ARM Cortex-A9','bytes':size})
            except (ValueError, OSError) as ex:
                return self.reply({'error':str(ex)},400)
        if urlsplit(self.path).path == '/api/image/upload':
            try:
                size=int(self.headers.get('Content-Length','0'))
                algorithm=int(self.headers.get('X-Image-Algorithm','0'))
                strength=int(self.headers.get('X-Image-Strength','60'))
                threshold=int(self.headers.get('X-Image-Threshold','0'))
                filename=unquote(self.headers.get('X-Image-Name','image'))
                filename=Path(filename.replace('\\','/')).name[:180]
                if size<8 or size>2*1024*1024: raise ValueError('图像文件需为 8 字节至 2 MiB')
                suffix=Path(filename).suffix.lower()
                if suffix not in ('.jpg','.jpeg','.png','.bmp'): raise ValueError('请选择 JPEG、PNG 或 BMP 图片')
                if algorithm not in (0,2,3,4,5,8): raise ValueError('该图像功能未在控制台开放')
                if strength<0 or strength>100: raise ValueError('算法强度需为 0–100')
                if threshold<0 or threshold>255: raise ValueError('边缘阈值需为 0–255')
                if algorithm not in (3,5): threshold=0
                payload=self.rfile.read(size)
                if len(payload)!=size: raise ValueError('上传数据长度不完整')
                signature=payload[:8]
                valid_signature=(suffix in ('.jpg','.jpeg') and signature.startswith(b'\xff\xd8\xff')) or (suffix=='.png' and signature==b'\x89PNG\r\n\x1a\n') or (suffix=='.bmp' and signature[:2]==b'BM')
                if not valid_signature: raise ValueError('文件内容与图片格式不匹配，请重新选择原始图片文件')
                with lock:
                    if state['recovering'] or state['recovery_required']: return self.reply({'error':state.get('recovery_error') or '板卡尚未恢复确认；请先恢复板卡再上传'},409)
                    if port is None or not port.is_open: return self.reply({'error':'串口未连接'},409)
                    telemetry=state.get('telemetry') or {}
                    if not state.get('last_rx') or state.get('link_stale') or time.time()-state['last_rx']>3:
                        return self.reply({'error':'板卡状态数据已过期，请确认开发板运行并收到实时串口状态'},409)
                    firmware_version=int(telemetry.get('firmware_version',0))
                    required_version=60
                    if firmware_version<required_version or int(telemetry.get('image_cpu1_ready',0))!=1:
                        return self.reply({'error':f'当前图像处理需要 V{required_version} 固件且 CPU1 图像核已就绪'},409)
                    if audio_state['status'] in ACTIVE_AUDIO_STATES or image_state['status'] in ACTIVE_IMAGE_STATES:
                        return self.reply({'error':'上一份音频或图像任务仍在运行'},409)
                    if int(telemetry.get('image_worker_state',0)) in (1,2):
                        return self.reply({'error':'CPU1 图像核仍处于忙碌状态，可能是上一次任务卡住。请先恢复板卡，再重新提交图片。'},409)
                    run_id=int(image_state.get('run_id',0))+1
                    state['upload_generation'] += 1
                    generation=state['upload_generation']
                    image_state.update(run_id=run_id,started_at=time.time(),processing_started_at=None,result_transfer_started_at=None,completed_at=None,status='queued',filename=filename,bytes=size,source_bytes=payload,progress=0,message='准备把原图送到开发板。',result=None,output_bytes=bytearray(),output_bytes_expected=0,output_width=0,output_height=0)
                try:
                    persist_active_task('image',run_id,generation)
                except OSError as ex:
                    with lock:
                        image_state.update(status='error',completed_at=time.time(),message='无法保存任务恢复记录，已阻止上传：'+str(ex))
                        state.update(recovery_required=True,recovery_reason='无法保存活动任务恢复记录',recovery_error=str(ex))
                    persist_image_run()
                    return self.reply({'error':'无法保存恢复记录，未启动图像任务：'+str(ex)},500)
                persist_image_run()
                threading.Thread(target=send_image_payload,args=(payload,filename,run_id,algorithm,strength,threshold,generation),daemon=True).start()
                return self.reply({'started':True,'run_id':run_id,'processor':'Zynq ARM Cortex-A9','bytes':size})
            except (ValueError,OSError) as ex:
                return self.reply({'error':str(ex)},400)
        if self.path != '/api/send': return self.reply({'error':'不存在'},404)
        try:
            size=int(self.headers.get('Content-Length','0'))
            if size < 1 or size > 128: raise ValueError('命令过长')
            cmd=json.loads(self.rfile.read(size)).get('command','')
            if not isinstance(cmd,str) or len(cmd)!=1 or cmd not in '10bsrmfah+-?j k l n v w c p t e d x z g o u q U Y Q R [ ]'.replace(' ','')+'ABCDEFGHIJKLMNOP': raise ValueError('不支持的命令')
            with lock:
                if state['recovering'] or state['recovery_required']: return self.reply({'error':'板端正在恢复或状态未确认，暂不发送控制命令'},409)
                if audio_state['status'] in ('queued','sending','receiving','waiting_board','processing','returning_results','returning_audio') or image_state['status'] in ('queued','sending','receiving'): return self.reply({'error':'音频或图像上传占用串口期间暂不发送命令'},409)
                if port is None or not port.is_open: return self.reply({'error':'串口未连接'},409)
                if not state.get('last_rx') or state.get('link_stale') or time.time()-state['last_rx']>3: return self.reply({'error':'板端状态数据已过期，暂不发送控制命令'},409)
                active_port = port
            with serial_tx_lock: active_port.write(cmd.encode('ascii'))
            event('发送',cmd)
            self.reply({'sent':cmd, 'note':'已发送，执行结果以板子回传为准'})
        except (ValueError, serial.SerialException, OSError) as ex: self.reply({'error':str(ex)},400)

restore_active_task()
restore_last_image_run()
pc_ble=PcBle(event)
threading.Thread(target=reader, daemon=True).start()
web_port = int(os.environ.get('ZYBO_CONSOLE_PORT', '8765'))
print(f'Zybo live console: http://127.0.0.1:{web_port}', flush=True)
ThreadingHTTPServer(('127.0.0.1',web_port), Handler).serve_forever()
