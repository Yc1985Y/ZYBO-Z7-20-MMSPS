set root E:/zybo/sensor_project
hsi::open_hw_design $root/sensor_hw.xsa
hsi::create_sw_design monitor_bsp -proc ps7_cortexa9_0 -os standalone
hsi::set_property CONFIG.stdin ps7_uart_1 [hsi::get_os]
hsi::set_property CONFIG.stdout ps7_uart_1 [hsi::get_os]
hsi::generate_bsp -dir $root/bsp
puts "MONITOR_BSP_SUCCESS"
exit
