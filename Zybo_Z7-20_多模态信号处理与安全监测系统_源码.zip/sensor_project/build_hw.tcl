set root E:/zybo/sensor_project
create_project sensor_hw $root/sensor_hw -part xc7z020clg400-1 -force
set_property board_part digilentinc.com:zybo-z7-20:part0:1.2 [current_project]
set_property ip_repo_paths $root/ip_repo [current_project]
update_ip_catalog
add_files $root/rtl/monitor_core.v
add_files -fileset constrs_1 $root/pins.xdc
create_bd_design design_1
create_bd_cell -type ip -vlnv xilinx.com:ip:processing_system7:5.5 ps
apply_bd_automation -rule xilinx.com:bd_rule:processing_system7 -config {make_external "FIXED_IO, DDR" apply_board_preset "1" Master "Disable" Slave "Disable"} [get_bd_cells ps]
set_property -dict [list CONFIG.PCW_USE_M_AXI_GP0 {1} CONFIG.PCW_FPGA0_PERIPHERAL_FREQMHZ {50.000000}] [get_bd_cells ps]
create_bd_cell -type module -reference monitor_core core
create_bd_cell -type ip -vlnv xilinx.com:ip:axi_gpio:2.0 control_gpio
set_property -dict [list CONFIG.C_GPIO_WIDTH {32} CONFIG.C_ALL_OUTPUTS {1} CONFIG.C_DOUT_DEFAULT {0x01F40801}] [get_bd_cells control_gpio]
create_bd_cell -type ip -vlnv xilinx.com:ip:axi_gpio:2.0 input_gpio
set_property -dict [list CONFIG.C_GPIO_WIDTH {8} CONFIG.C_ALL_INPUTS {1} CONFIG.C_IS_DUAL {1} CONFIG.C_GPIO2_WIDTH {32} CONFIG.C_ALL_INPUTS_2 {1}] [get_bd_cells input_gpio]
create_bd_cell -type ip -vlnv xilinx.com:ip:axi_gpio:2.0 status_gpio
set_property -dict [list CONFIG.C_GPIO_WIDTH {32} CONFIG.C_ALL_INPUTS {1}] [get_bd_cells status_gpio]
create_bd_cell -type ip -vlnv zybo.lab:user:sonar_axi:1.0 sonar
create_bd_cell -type ip -vlnv xilinx.com:ip:axi_uartlite:2.0 ble_uart
set_property -dict [list CONFIG.C_BAUDRATE {115200} CONFIG.C_DATA_BITS {8} CONFIG.C_USE_PARITY {0}] [get_bd_cells ble_uart]
create_bd_cell -type ip -vlnv xilinx.com:ip:axi_gpio:2.0 ble_gpio
set_property -dict [list CONFIG.C_GPIO_WIDTH {2} CONFIG.C_ALL_OUTPUTS {1} CONFIG.C_DOUT_DEFAULT {0x00000001} CONFIG.C_IS_DUAL {1} CONFIG.C_GPIO2_WIDTH {2} CONFIG.C_ALL_INPUTS_2 {1}] [get_bd_cells ble_gpio]
foreach name {control_gpio input_gpio status_gpio sonar ble_uart ble_gpio} {
    apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master "/ps/M_AXI_GP0" Clk "Auto"} [get_bd_intf_pins $name/S_AXI]
}
connect_bd_net [get_bd_pins control_gpio/gpio_io_o] [get_bd_pins core/control]
connect_bd_net [get_bd_pins core/stable_inputs] [get_bd_pins input_gpio/gpio_io_i]
connect_bd_net [get_bd_pins core/ticks_ms] [get_bd_pins input_gpio/gpio2_io_i]
connect_bd_net [get_bd_pins core/monitor_status] [get_bd_pins status_gpio/gpio_io_i]
connect_bd_net [get_bd_pins ps/FCLK_CLK0] [get_bd_pins core/clk]
connect_bd_net [get_bd_pins sonar/alarm_out] [get_bd_pins core/external_alarm]
foreach {name dir} {sonar_pwm I sonar_run O} {
 create_bd_port -dir $dir $name
 connect_bd_net [get_bd_ports $name] [get_bd_pins sonar/$name]
}
foreach {name dir pin} {ble_rxd I ble_uart/rx ble_txd O ble_uart/tx} {
 create_bd_port -dir $dir $name
 connect_bd_net [get_bd_ports $name] [get_bd_pins $pin]
}
create_bd_port -dir O -from 1 -to 0 ble_control
create_bd_port -dir I -from 1 -to 0 ble_status
connect_bd_net [get_bd_ports ble_control] [get_bd_pins ble_gpio/gpio_io_o]
connect_bd_net [get_bd_ports ble_status] [get_bd_pins ble_gpio/gpio2_io_i]
set reset_cells [get_bd_cells -hier -filter {VLNV =~ xilinx.com:ip:proc_sys_reset:*}]
if {[llength $reset_cells] != 1} {error "Could not uniquely identify peripheral reset"}
connect_bd_net [get_bd_pins [lindex $reset_cells 0]/peripheral_aresetn] [get_bd_pins core/resetn]
foreach {name dir} {switches I buttons I leds O} {
    create_bd_port -dir $dir -from 3 -to 0 $name
    connect_bd_net [get_bd_ports $name] [get_bd_pins core/$name]
}
assign_bd_address -offset 0x41200000 -range 64K -target_address_space [get_bd_addr_spaces ps/Data] [get_bd_addr_segs control_gpio/S_AXI/Reg] -force
assign_bd_address -offset 0x41210000 -range 64K -target_address_space [get_bd_addr_spaces ps/Data] [get_bd_addr_segs input_gpio/S_AXI/Reg] -force
assign_bd_address -offset 0x41220000 -range 64K -target_address_space [get_bd_addr_spaces ps/Data] [get_bd_addr_segs status_gpio/S_AXI/Reg] -force
assign_bd_address -offset 0x43C00000 -range 4K -target_address_space [get_bd_addr_spaces ps/Data] [get_bd_addr_segs sonar/S_AXI/Reg] -force
assign_bd_address -offset 0x42C00000 -range 64K -target_address_space [get_bd_addr_spaces ps/Data] [get_bd_addr_segs ble_uart/S_AXI/Reg] -force
assign_bd_address -offset 0x41230000 -range 64K -target_address_space [get_bd_addr_spaces ps/Data] [get_bd_addr_segs ble_gpio/S_AXI/Reg] -force
validate_bd_design
save_bd_design
set bd [get_files */design_1.bd]
generate_target all $bd
add_files -norecurse [make_wrapper -files $bd -top]
set_property top design_1_wrapper [current_fileset]
update_compile_order -fileset sources_1
launch_runs impl_1 -to_step write_bitstream -jobs 4
wait_on_run impl_1
if {[get_property PROGRESS [get_runs impl_1]] ne "100%"} {error "Implementation failed"}
write_hw_platform -fixed -include_bit -force -file $root/sensor_hw.xsa
puts "MONITOR_HARDWARE_SUCCESS"
close_project
