> **已被新方案取代**：用户允许 PS ARM 或 PL 计算，但明确禁止电脑执行音频 DSP。首版改为 ARM Cortex-A9 解码与分析，见 SYSTEM_DESIGN_WAV_DSP.md。此文件仅保留历史方案标记。
