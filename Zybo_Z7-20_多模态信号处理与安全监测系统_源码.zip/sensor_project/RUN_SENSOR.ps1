param([string]$VitisRoot = $env:XILINX_VITIS)

$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($VitisRoot)) {
    $VitisRoot = 'C:\Xilinx\Vitis\2020.2'
}
$projectRoot = Split-Path -Parent $PSScriptRoot
$xsct = Join-Path $VitisRoot 'bin\xsct.bat'
$downloadTcl = Join-Path $projectRoot 'control_center\download.tcl'
$hardware = Join-Path $projectRoot 'release\sensor_hw.xsa'
$bitstream = Join-Path $projectRoot 'release\sensor_hw.bit'
$initTcl = Join-Path $PSScriptRoot 'ps7_init.tcl'
$firmware = Join-Path $projectRoot 'release\sensor_image_v60_quality_final.elf'

& $xsct $downloadTcl $hardware $bitstream $initTcl $firmware
if ($LASTEXITCODE -ne 0) { throw 'Board download failed' }