param([string]$OutputPath = '')

$ErrorActionPreference = 'Stop'
$project = $PSScriptRoot
$firmware = Join-Path $project 'firmware'
$output = if ($OutputPath) { $OutputPath } else { Join-Path $firmware 'sensor_image_candidate.elf' }
$workerElf = Join-Path $firmware 'image_cpu1_worker.elf'
$workerBin = Join-Path $firmware 'image_cpu1_worker.bin'
$workerBlob = Join-Path $firmware 'image_cpu1_worker_blob.o'
$workerBuild = Join-Path $firmware 'build_image_cpu1'
$cpu0Linker = Join-Path $firmware 'image_cpu0.ld'
$builder = Join-Path (Split-Path $PSScriptRoot -Parent) "control_center\build_app.ps1"
$taskGcc = 'E:/Xilinx/Vitis/2020.2/gnu/aarch32/nt/gcc-arm-none-eabi/bin'
$taskGxx = Join-Path $taskGcc 'arm-none-eabi-g++.exe'
$taskSupport = 'E:/zybo/auto_hello/vitis_ws/hello_world/src'
$bsp = 'E:/zybo/auto_hello/vitis_ws/hello_hw/ps7_cortexa9_0/standalone_domain/bsp/ps7_cortexa9_0'
$tflm = Join-Path $firmware 'third_party/tflite_micro'
$captureTflmLogs = $env:ZYBO_DIAG_TFLM_CAPTURE -eq '1'
$tflmLibrary = Join-Path $tflm 'gen/zybo_cortex_a9_armv7-a_release_gcc/lib/libtensorflow-microlite.a'
if ($env:ZYBO_DIAG_TFLM_LIBRARY) {
    $tflmLibrary = $env:ZYBO_DIAG_TFLM_LIBRARY
} else {
    $tflmBuildName = if ($captureTflmLogs) { 'build_tflm_signed_quant_diag' } else { 'build_tflm_signed_quant' }
    $tflmLibrary = Join-Path $firmware (Join-Path $tflmBuildName 'libtensorflow-microlite.a')
    if ($captureTflmLogs) {
        & (Join-Path $project 'BUILD_TFLM_SIGNED_QUANT_LIBRARY.ps1') -Diagnostic
    } else {
        & (Join-Path $project 'BUILD_TFLM_SIGNED_QUANT_LIBRARY.ps1')
    }
    if ($LASTEXITCODE -ne 0) { throw 'Signed-quantization TFLite Micro library build failed.' }
}
$tflmIncludes = @("-I$tflm", "-I$(Join-Path $tflm 'tensorflow/lite/micro/tools/make/downloads/flatbuffers/include')")
$cFlags = @('-mcpu=cortex-a9','-marm','-mfpu=neon-vfpv3','-mfloat-abi=hard','-O2','-g3','-Wall','-Wextra','-fno-common','-ffunction-sections','-fdata-sections',"-I$bsp/include","-I$taskSupport","-I$firmware")
$cxxFlags = $cFlags + @('-fno-rtti','-fno-exceptions','-fno-threadsafe-statics','-std=c++17','-DTFLM_REMOVE_VIRTUAL_DELETE','-DTF_LITE_DISABLE_X86_NEON','-DTF_LITE_MCU_DEBUG_LOG') + $tflmIncludes
if (-not ($env:ZYBO_DIAG_TFLM_CAPTURE -eq '1')) { $cxxFlags += '-DTF_LITE_STRIP_ERROR_STRINGS' }
$aiCxxFlags = $cxxFlags
$workerCFlags = $cFlags
if ($captureTflmLogs) {
    $aiCxxFlags += '-DIMAGE_TFLM_DIAGNOSTIC'
    $workerCFlags += '-DIMAGE_TFLM_DIAGNOSTIC'
}
$workerObjects = @(
    (Join-Path $workerBuild 'image_cpu1_start.o'),
    (Join-Path $workerBuild 'image_cpu1.o'),
    (Join-Path $workerBuild 'image_stage.o'),
    (Join-Path $workerBuild 'image_lab.o'),
    (Join-Path $workerBuild 'image_ai.o'),
    (Join-Path $workerBuild 'image_model_data.o'),
    (Join-Path $workerBuild 'image_detection_model.o'),
    (Join-Path $workerBuild 'image_detection_postprocess.o'),
    (Join-Path $workerBuild 'image_zero_dce_model.o'),
    (Join-Path $workerBuild 'image_dncnn_model.o'),
    (Join-Path $workerBuild 'image_zero_dce_fast_model.o'),
    (Join-Path $workerBuild 'image_dncnn_fast_model.o')
)
$debugCaptureObject = Join-Path $workerBuild 'image_tflm_debug_capture.o'
if ($captureTflmLogs) { $workerObjects += $debugCaptureObject }
$linkerSource = [IO.File]::ReadAllText((Join-Path $taskSupport 'lscript.ld'))
$defaultHeap = '_HEAP_SIZE = DEFINED(_HEAP_SIZE) ? _HEAP_SIZE : 0x2000;'
if (-not $linkerSource.Contains($defaultHeap)) { throw 'Expected Vitis 2020.2 linker heap definition was not found' }
[IO.File]::WriteAllText($cpu0Linker,$linkerSource.Replace($defaultHeap,'_HEAP_SIZE = 0x06000000;'),[Text.UTF8Encoding]::new($false))

if (-not (Test-Path -LiteralPath $tflmLibrary)) { throw 'Cortex-A9 TFLite Micro library is missing; build it with TARGET=zybo_cortex_a9 first.' }
New-Item -ItemType Directory -Force -Path $workerBuild | Out-Null
Push-Location $firmware
try {
    & "$taskGcc/arm-none-eabi-gcc.exe" @cFlags -c image_cpu1_start.S -o $workerObjects[0]
    if ($LASTEXITCODE -ne 0) { throw 'CPU1 startup assembly compile failed' }
    & "$taskGcc/arm-none-eabi-gcc.exe" @workerCFlags -c image_cpu1.c -o $workerObjects[1]
    if ($LASTEXITCODE -ne 0) { throw 'CPU1 worker compile failed' }
    & "$taskGcc/arm-none-eabi-gcc.exe" @workerCFlags -c image_stage.c -o $workerObjects[2]
    if ($LASTEXITCODE -ne 0) { throw 'CPU1 stage telemetry compile failed' }
    & "$taskGcc/arm-none-eabi-gcc.exe" @workerCFlags -mno-unaligned-access -DIMAGE_AI_CPU1 -c image_lab.c -o $workerObjects[3]
    if ($LASTEXITCODE -ne 0) { throw 'CPU1 image-lab compile failed' }
    & $taskGxx @aiCxxFlags -c image_ai.cc -o $workerObjects[4]
    if ($LASTEXITCODE -ne 0) { throw 'CPU1 TFLite Micro image classifier compile failed' }
    if ($captureTflmLogs) {
        & $taskGxx @cxxFlags -c image_tflm_debug_capture.cc -o $debugCaptureObject
        if ($LASTEXITCODE -ne 0) { throw 'CPU1 TFLite diagnostic logger compile failed' }
    }
    & "$taskGcc/arm-none-eabi-gcc.exe" @cFlags -c image_model_data.S -o $workerObjects[5]
    if ($LASTEXITCODE -ne 0) { throw 'CPU1 INT8 model embedding failed' }
    & "$taskGcc/arm-none-eabi-gcc.exe" @cFlags -c image_detection_model.S -o $workerObjects[6]
    if ($LASTEXITCODE -ne 0) { throw 'CPU1 SSD-MobileNet model embedding failed' }
    & $taskGxx @cxxFlags -c image_detection_postprocess.cc -o $workerObjects[7]
    if ($LASTEXITCODE -ne 0) { throw 'CPU1 quantized SSD postprocess adaptation compile failed' }
    & "$taskGcc/arm-none-eabi-gcc.exe" @cFlags -c image_zero_dce_model.S -o $workerObjects[8]
    if ($LASTEXITCODE -ne 0) { throw 'CPU1 Zero-DCE INT8 model embedding failed' }
    & "$taskGcc/arm-none-eabi-gcc.exe" @cFlags -c image_dncnn_model.S -o $workerObjects[9]
    if ($LASTEXITCODE -ne 0) { throw 'CPU1 DnCNN-S INT8 model embedding failed' }
    if (-not (Test-Path -LiteralPath 'models/zero_dce/dcenet_fast_80x60_int8.tflite') -or
        -not (Test-Path -LiteralPath 'models/dncnn_s/dncnn_s_sigma25_fast_40x30_int8.tflite')) {
        throw 'Fast image models are missing; run tools/prepare_fast_image_models.py first.'
    }
    & "$taskGcc/arm-none-eabi-gcc.exe" @cFlags -c image_zero_dce_fast_model.S -o $workerObjects[10]
    if ($LASTEXITCODE -ne 0) { throw 'CPU1 fast Zero-DCE model embedding failed' }
    & "$taskGcc/arm-none-eabi-gcc.exe" @cFlags -c image_dncnn_fast_model.S -o $workerObjects[11]
    if ($LASTEXITCODE -ne 0) { throw 'CPU1 fast DnCNN-S model embedding failed' }
    & "$taskGcc/arm-none-eabi-gcc.exe" -mcpu=cortex-a9 -marm -mfpu=neon-vfpv3 -mfloat-abi=hard -O2 -g3 -nostartfiles "-specs=$taskSupport/Xilinx.spec" "-Wl,--build-id=none" '-Wl,--gc-sections' "-Wl,-T,$firmware/image_cpu1.ld" "-Wl,-Map,$workerElf.map" "-L$bsp/lib" @workerObjects '-Wl,--start-group' $tflmLibrary -lxil -lc -lm -lgcc '-Wl,--end-group' -o $workerElf
    if ($LASTEXITCODE -ne 0) { throw 'CPU1 image worker link failed' }
} finally { Pop-Location }
& "$taskGcc/arm-none-eabi-objcopy.exe" -O binary $workerElf $workerBin
if ($LASTEXITCODE -ne 0) { throw 'CPU1 worker binary extraction failed' }
$objcopyStart = Push-Location $firmware
try {
    & "$taskGcc/arm-none-eabi-objcopy.exe" -I binary -O elf32-littlearm -B arm 'image_cpu1_worker.bin' 'image_cpu1_worker_blob.o' '--rename-section' '.data=.rodata,alloc,load,readonly,data,contents'
} finally { Pop-Location }
if ($LASTEXITCODE -ne 0) { throw 'CPU1 worker image embedding failed' }

& $builder -Source (Join-Path $firmware 'main.c') -Output $output -AdditionalSources @(
    (Join-Path $firmware 'ble_service.c'),
    (Join-Path $firmware 'audio_dsp.c'),
    (Join-Path $firmware 'minimp3_impl.c'),
    (Join-Path $firmware 'image_lab.c'),
    $workerBlob
) -Optimization '2' -LinkerScript $cpu0Linker
if ($LASTEXITCODE -ne 0) { throw 'ARM image firmware build failed' }
Write-Host 'ARM image-lab candidate built. Existing sensor.elf was not overwritten.'
