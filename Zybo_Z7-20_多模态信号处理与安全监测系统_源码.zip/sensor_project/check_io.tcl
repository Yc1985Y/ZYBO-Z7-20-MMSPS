connect
after 3000
targets -set -filter {name =~ "*Cortex-A9*#0"}
loadhw -hw E:/zybo/sensor_project/sensor_hw.xsa -mem-ranges [list {0x40000000 0xbfffffff}]
foreach addr {0x42C00008 0x41230000 0x41230008 0x43C00004 0x43C00010 0x43C00014 0x43C00018 0x43C0001C} {puts [mrd $addr]}
disconnect
exit
