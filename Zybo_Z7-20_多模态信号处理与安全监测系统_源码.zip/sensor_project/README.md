# Zybo Z7-20 板端音频分析与近距安全监测

当前项目聚焦两项可演示功能：在开发板 ARM 上处理 WAV/MP3 文件并返回真实分析结果；用 MAXSONAR、FPGA、板载 LED 和 BLE 实现近距风险演示。音频数据由电脑通过 USB 串口传入，解码和处理都在 Zynq ARM Cortex-A9 执行，电脑控制台仅负责上传、显示和交互。

## 当前模块与接口

- MAXSONAR：JE1–JE6，PWM 接入 FPGA 测距 IP。
- Pmod BLE：JD 全部十二针，UART 与状态脚用于电脑/手机无线控制。
- 板载 LED、开关和按键：本地状态提示及演示控制。
- 音频文件分析：ARM 端执行 WAV/MP3 解码、滤波、分帧 FFT 与指标计算；控制台显示上传文件的时域、频谱幅度、相位、时频图和处理指标，并提供输入/输出差值时频图、同步时间游标、原音/处理音试听和处理后 WAV 下载。
- 外接模拟采集、模拟输出和声音播放模块已从当前固件、硬件构建和控制台移除；之前的接线不再需要。

## 工程文件

- Vivado 工程：`sensor_hw/sensor_hw.xpr`
- 硬件构建脚本：`build_hw.tcl`
- ARM 主程序：`firmware/main.c`
- ARM 音频处理：`firmware/audio_dsp.c`、`firmware/audio_dsp.h`
- BLE 服务：`firmware/ble_service.c`
- 测距逻辑：`rtl/sonar_axi.v`，封装 IP 位于 `ip_repo/sonar_axi`
- LED、按键和状态逻辑：`rtl/monitor_core.v`
- 引脚约束：`pins.xdc`
- 接线说明：`WIRING.md`
- 控制台：`E:/zybo/control_center/`，网址 `http://127.0.0.1:8765/`

## 音频实验

在实时控制台顶部点击“增强音频实验室”，选择 WAV 或 MP3 文件和滤波选项后上传。网页显示文件传输、ARM 解码/滤波/FFT、图表回传和试听音频回传四个阶段。固件回传本次运行的原始/处理后波形、幅度谱、相位谱、时频帧和量化指标，并回传最多 10 秒的处理后 PCM 试听片段；不超过 10 秒时完整回传。试听音频为 16 kHz、16-bit 单声道。页面可切换播放原音和 ARM 输出，并将真实回传数据封装成 WAV 下载。完整文件仍在 ARM 上分析，电脑端只负责传输、展示与播放。

时频差值图根据 ARM 回传的输入/输出频带显示能量变化；悬停可同步移动输入、输出和差值图的时间游标，点击图表可跳到试听位置。总流程用时与 ARM 算法计算时间分别显示，避免把串口传输延迟误当成 DSP 耗时。

## 距离监测与控制

MAXSONAR 使用 JE4 的 PWM 输入、JE2 的运行使能。50 MHz 脉宽计数按模块标定公式换算距离；原模块分辨率约 2.54 cm。无效信号和超时数据会按无效状态处理，不以旧值表示安全。默认距离阈值为 500 mm，按键/控制台可调整阈值并切换布防；分级状态由板载 LED 表示。

BLE 使用 JD2/T15 作为主机 TX、JD3/P14 作为主机 RX；JD8/U15 控制模块复位，JD4/R14 为 CTS，JD10/V18 读取连接状态，JD1/T14 读取 RTS。UART 115200/8N1。BLE JP1 保持打开为应用模式。无线端与 USB 控制台使用同一组板端命令。

常用无线文本命令：`led 5`、`chase`、`distance alarm`、`distance +`、`distance -`、`ack`、`guard`、`disarm`、`status`。通过 BLE GATT 终端发送时每条命令附加 LF 换行。

## 构建和运行

Vivado/Vitis 版本为 2020.2。完整硬件平台由 `package_ip.tcl` 与 `build_hw.tcl` 生成；ARM 应用构建脚本位于 `E:/zybo/control_center/build_app.ps1`；上板脚本为 `RUN_SENSOR.ps1`。先生成硬件平台，再编译 ARM 应用，最后通过 JTAG 下载。串口控制台服务与本工程固件配套运行。
