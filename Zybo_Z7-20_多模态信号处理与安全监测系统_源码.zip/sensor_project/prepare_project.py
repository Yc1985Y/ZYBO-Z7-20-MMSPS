from pathlib import Path
root=Path('E:/zybo/sensor_project')
p=root/'build_hw.tcl'
s=p.read_text(encoding='utf-8').replace('E:/zybo/monitor_project','E:/zybo/sensor_project').replace('monitor_hw','sensor_hw')
s=s.replace('add_files $root/rtl/monitor_core.v', 'set_property ip_repo_paths $root/ip_repo [current_project]\nupdate_ip_catalog\nadd_files $root/rtl/monitor_core.v')
s=s.replace('foreach name {control_gpio input_gpio status_gpio} {', 'create_bd_cell -type ip -vlnv zybo.lab:user:sonar_axi:1.0 sonar\nforeach name {control_gpio input_gpio status_gpio sonar} {')
s=s.replace('connect_bd_net [get_bd_pins ps/FCLK_CLK0] [get_bd_pins core/clk]', 'connect_bd_net [get_bd_pins ps/FCLK_CLK0] [get_bd_pins core/clk]\nconnect_bd_net [get_bd_pins sonar/alarm_out] [get_bd_pins core/external_alarm]\nforeach {name dir} {sonar_pwm I sonar_run O} {\n create_bd_port -dir $dir $name\n connect_bd_net [get_bd_ports $name] [get_bd_pins sonar/$name]\n}')
s=s.replace('validate_bd_design', 'assign_bd_address -offset 0x43C00000 -range 4K -target_address_space [get_bd_addr_spaces ps/Data] [get_bd_addr_segs sonar/S_AXI/Reg] -force\nvalidate_bd_design')
p.write_text(s,encoding='utf-8')
p=root/'build_bsp.tcl';s=p.read_text(encoding='utf-8').replace('E:/zybo/monitor_project','E:/zybo/sensor_project').replace('monitor_hw.xsa','sensor_hw.xsa');p.write_text(s,encoding='utf-8')
