$ErrorActionPreference = 'Stop'
$project = 'E:/zybo/sensor_project'
$firmware = Join-Path $project 'firmware'
$tflm = Join-Path $firmware 'third_party/tflite_micro'
$target = Join-Path $tflm 'gen/zybo_cortex_a9_armv7-a_release_gcc'
$releaseLibrary = Join-Path $target 'lib/libtensorflow-microlite.a'
$diagDir = Join-Path $firmware 'build_tflm_diag'
$diagLibrary = Join-Path $diagDir 'libtensorflow-microlite.a'
$compiler = 'E:/Xilinx/Vitis/2020.2/gnu/aarch32/nt/gcc-arm-none-eabi/bin'
$gxx = Join-Path $compiler 'arm-none-eabi-g++.exe'
$ar = Join-Path $compiler 'arm-none-eabi-ar.exe'
$ranlib = Join-Path $compiler 'arm-none-eabi-ranlib.exe'

if (-not (Test-Path -LiteralPath $releaseLibrary)) {
    throw "Baseline TFLite Micro library is missing: $releaseLibrary"
}
New-Item -ItemType Directory -Force -Path $diagDir | Out-Null
Copy-Item -LiteralPath $releaseLibrary -Destination $diagLibrary -Force

$flags = @(
    '-fno-rtti','-fno-exceptions','-fno-threadsafe-statics',
    '-Wnon-virtual-dtor','-fno-unwind-tables','-fno-asynchronous-unwind-tables',
    '-ffunction-sections','-fdata-sections','-fmessage-length=0',
    '-DTFLM_REMOVE_VIRTUAL_DELETE','-DTF_LITE_DISABLE_X86_NEON',
    '-DKERNELS_OPTIMIZED_FOR_SPEED','-DNDEBUG','-std=c++17',
    '-mcpu=cortex-a9','-mfpu=neon-vfpv3','-mfloat-abi=hard','-marm',
    '-DTF_LITE_MCU_DEBUG_LOG','-funsigned-char','-mlittle-endian',
    '-Wno-type-limits','-fomit-frame-pointer','-Os',
    '-I.','-Itensorflow/lite/micro/tools/make/downloads',
    '-Itensorflow/lite/micro/tools/make/downloads/flatbuffers/include',
    '-Itensorflow/lite/micro/tools/make/downloads/kissfft',
    "-I$(Join-Path $target 'genfiles')"
)

$sources = @(
    @{ Source='tensorflow/lite/micro/micro_log.cc'; Object='micro_log.o' },
    @{ Source='tensorflow/lite/micro/micro_interpreter.cc'; Object='micro_interpreter.o' },
    @{ Source='tensorflow/lite/micro/micro_interpreter_graph.cc'; Object='micro_interpreter_graph.o' },
    @{ Source='tensorflow/lite/micro/micro_allocator.cc'; Object='micro_allocator.o' }
)
$objects = @()
Push-Location $tflm
try {
    foreach ($entry in $sources) {
        $object = Join-Path $diagDir $entry.Object
        & $gxx @flags '-c' $entry.Source '-o' $object
        if ($LASTEXITCODE -ne 0) { throw "Failed compiling diagnostic object $($entry.Source)" }
        $objects += $object
    }
} finally {
    Pop-Location
}

& $ar 'r' $diagLibrary @objects
if ($LASTEXITCODE -ne 0) { throw 'Failed replacing diagnostic objects in the copied TFLite Micro library' }
& $ranlib $diagLibrary
if ($LASTEXITCODE -ne 0) { throw 'Failed indexing the diagnostic TFLite Micro library' }

Write-Host "Diagnostic library ready: $diagLibrary"
