param([switch]$Diagnostic)

$ErrorActionPreference = 'Stop'
$firmware = 'E:/zybo/sensor_project/firmware'
$tflm = Join-Path $firmware 'third_party/tflite_micro'
$target = Join-Path $tflm 'gen/zybo_cortex_a9_armv7-a_release_gcc'
$releaseLibrary = Join-Path $target 'lib/libtensorflow-microlite.a'
$buildName = if ($Diagnostic) { 'build_tflm_signed_quant_diag' } else { 'build_tflm_signed_quant' }
$buildDir = Join-Path $firmware $buildName
$library = Join-Path $buildDir 'libtensorflow-microlite.a'
$compiler = 'E:/Xilinx/Vitis/2020.2/gnu/aarch32/nt/gcc-arm-none-eabi/bin'
$gxx = Join-Path $compiler 'arm-none-eabi-g++.exe'
$ar = Join-Path $compiler 'arm-none-eabi-ar.exe'
$ranlib = Join-Path $compiler 'arm-none-eabi-ranlib.exe'

if (-not (Test-Path -LiteralPath $releaseLibrary)) {
    throw "TFLite Micro release library is missing: $releaseLibrary"
}
New-Item -ItemType Directory -Force -Path $buildDir | Out-Null
Copy-Item -LiteralPath $releaseLibrary -Destination $library -Force

$flags = @(
    '-fno-rtti','-fno-exceptions','-fno-threadsafe-statics',
    '-fno-unwind-tables','-fno-asynchronous-unwind-tables',
    '-ffunction-sections','-fdata-sections','-fmessage-length=0',
    '-DTFLM_REMOVE_VIRTUAL_DELETE','-DTF_LITE_DISABLE_X86_NEON',
    '-DKERNELS_OPTIMIZED_FOR_SPEED','-DNDEBUG','-std=c++17',
    '-mcpu=cortex-a9','-mfpu=neon-vfpv3','-mfloat-abi=hard','-marm',
    '-DTF_LITE_MCU_DEBUG_LOG','-funsigned-char','-mlittle-endian',
    '-Wno-type-limits','-fomit-frame-pointer','-O2',
    '-I.','-Itensorflow/lite/micro/tools/make/downloads',
    '-Itensorflow/lite/micro/tools/make/downloads/flatbuffers/include',
    '-Itensorflow/lite/micro/tools/make/downloads/kissfft',
    "-I$firmware",
    "-I$(Join-Path $target 'genfiles')"
)

$objects = @(
    @{ Source='tensorflow/lite/micro/kernels/concatenation.cc'; Object='concatenation.o' },
    @{ Source='tensorflow/lite/micro/kernels/conv.cc'; Object='conv.o' },
    @{ Source='tensorflow/lite/micro/kernels/depthwise_conv.cc'; Object='depthwise_conv.o' }
)
if ($Diagnostic) {
    $objects += @(
        @{ Source='tensorflow/lite/micro/micro_log.cc'; Object='micro_log.o' },
        @{ Source='tensorflow/lite/micro/micro_interpreter.cc'; Object='micro_interpreter.o' },
        @{ Source='tensorflow/lite/micro/micro_interpreter_graph.cc'; Object='micro_interpreter_graph.o' },
        @{ Source='tensorflow/lite/micro/micro_allocator.cc'; Object='micro_allocator.o' },
        @{ Source='tensorflow/lite/micro/kernels/conv_common.cc'; Object='conv_common.o' },
        @{ Source='tensorflow/lite/micro/kernels/depthwise_conv_common.cc'; Object='depthwise_conv_common.o' }
    )
} else {
    $flags += '-DTF_LITE_STRIP_ERROR_STRINGS'
}
Push-Location $tflm
try {
    foreach ($entry in $objects) {
        $objectPath = Join-Path $buildDir $entry.Object
        & $gxx @flags '-c' $entry.Source '-o' $objectPath
        if ($LASTEXITCODE -ne 0) {
            throw "Failed compiling signed-quantization kernel $($entry.Source)"
        }
        & $ar 'r' $library $objectPath
        if ($LASTEXITCODE -ne 0) {
            throw "Failed replacing $($entry.Object) in the candidate library"
        }
    }
} finally { Pop-Location }

& $ranlib $library
if ($LASTEXITCODE -ne 0) { throw 'Failed indexing the candidate TFLite Micro library' }
$members = & $ar 't' $library
foreach ($name in @('conv.o','depthwise_conv.o')) {
    if (@($members | Where-Object { $_ -eq $name }).Count -ne 1) {
        throw "Candidate library has an invalid $name member count"
    }
}
Write-Host "Signed-quantization TFLite Micro library ready: $library"
