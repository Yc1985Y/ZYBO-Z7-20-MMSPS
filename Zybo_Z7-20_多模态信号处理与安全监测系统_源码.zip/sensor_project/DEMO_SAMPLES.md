# Zybo EdgeLab 演示素材

图像、音频各整理 10 个可上传演示项，素材分别位于 `E:\zybo\sensor_project\test_image_samples` 和 `E:\zybo\sensor_project\test_audio_samples`。打开 `http://127.0.0.1:8765/image` 或 `/audio`，从对应图库选择样本；原文件由电脑传给 Zybo，处理结果和图表以 ARM 本次回传为准。所列上传样本均小于 2 MiB。音频页顶部提供 5 个一键强对照入口，其中语音样例会自动载入匹配的干净参考并提交处理；评分每次根据 ARM 回传重新计算。

## 图像演示 10 项

| # | 文件 | 建议操作 | 展示重点 |
|---|---|---|---|
| 1 | `demo_01_osaka_night_lowlight.jpg` | ARM AI → Zero-DCE 低照增强 | 暗部、霓虹招牌和水面反光同时存在，最适合看亮度与细节变化。配对参考是 `demo_01_osaka_night.jpg`。 |
| 2 | `demo_02_golden_retriever_sigma25.png` | ARM AI → DnCNN-S 降噪 | σ=25 可控噪声很明显，毛发和脸部轮廓便于观察。配对参考是 `demo_02_golden_retriever.jpg`。 |
| 3 | `demo_03_breda_street.jpg` | 传统算法 → Sobel / Otsu / CLAHE | 建筑、树、自行车、行人和车辆提供丰富边缘及明暗区域。 |
| 4 | `demo_02_golden_retriever.jpg` | ARM AI → MobileNetV2 分类；SSD-MobileNet 检测 | 金毛主体大且清晰。检测路线应返回 COCO `dog` 类框；分类和检测结果均以 ARM 本次回传为准。 |
| 5 | `grace_hopper.jpg` | ARM AI → 分类；传统算法 → Sobel | 人像主体清楚，适合展示与动物类别不同的分类对象。 |
| 6 | `grace_hopper_lowlight.png` | ARM AI → Zero-DCE | 与 Grace Hopper 原图配对，查看人物暗部增强。 |
| 7 | `grace_hopper_gaussian_sigma25.png` | ARM AI → DnCNN-S | 和原图来自同一照片，便于比较噪声抑制与纹理保留。 |
| 8 | `amp_sobel_smoke_222915.bmp` | 传统算法 → Sobel / Otsu | 几何图形边界清楚，适合作为结构化边缘基准。 |
| 9 | `demo_01_osaka_night.jpg` | ARM AI → 分类；传统算法 → 亮度/直方图分析 | 作为夜景参考输入，方便和低照版本并排比较。 |
| 10 | `demo_04_tabby_cat.jpg` | ARM AI → MobileNetV2 分类；SSD-MobileNet 检测 | 猫咪主体清晰。检测路线应返回 COCO `cat` 类框，与金毛构成两类目标检测对照；实际结果以 ARM 本次回传为准。 |

低照图和加噪图是由对应原图生成的可控输入，不是处理后的结果。大阪低照输入的亮度中位数由 46 降至 21；金毛 σ=25 输入的生成 PSNR 约 20.57 dB。Grace Hopper 与几何图用于扩充传统算法和分类对象。分类、增强、边缘或分割结果只有在本次 ARM 任务返回后才算实测。

## 音频演示 10 项

| # | 文件 | 建议操作 | 展示重点 |
|---|---|---|---|
| 1 | `demo_01_speech_static_noise.wav` | 自动分析并处理 | 稳定宽带底噪语音；已有 V26 板端 SNR 0.16 → 9.10 dB（+8.94 dB），开头底噪衰减 13.66 dB。参考文件：`demo_01_clean_speech_reference.wav`。 |
| 2 | `demo_02_speech_50hz_hum.wav` | 陷波 · 50 Hz | 语音叠加明显工频音；已有板端 SNR 提升 11.35 dB，50 Hz 能量占比 28.4% → 0.5%。参考文件：`demo_02_clean_speech_reference.wav`。 |
| 3 | `demo_03_1khz_tone_with_50hz_hum.wav` | 陷波 · 50 Hz | 频谱上 50 Hz 干扰峰下降，同时保留 1 kHz 有用信号峰。 |
| 4 | `demo_04_1khz_plus_4khz_lowpass.wav` | 两级低通 · 3 kHz | 观察 1 kHz 保留、4 kHz 削弱及高频能量变化。 |
| 5 | `demo_05_music_box_rhythm.wav` | 旁路或低通 | 音符谐波和节奏容易在波形、频谱、时频图中辨认。 |
| 6 | `demo_06_bell_speech_5s.mp3` | 低通或旁路 | 约 5 秒历史英语语音，展示 MP3 解码及语音频段变化；曾在 ARM 完成解码与滤波。 |
| 7 | `demo_07_bourne_birds_rain_8s.wav` | 自动分析或旁路 | 8 秒真实鸟鸣和雨声，适合看自然声音随时间的时频变化。 |
| 8 | `v26_60hz_hum.wav` | 陷波 · 60 Hz 或自动处理 | 可控 60 Hz 工频干扰样本，和 50 Hz 样本对照。 |
| 9 | `v26_low_frequency_rumble.wav` | 自动处理或高通 | 可控低频轰鸣，观察低频能量与高通前后差异。 |
| 10 | `v26_mixed_50hz_hum_broadband.wav` | 自动分析并处理 | 同时含 50 Hz 嗡声和宽带底噪，适合展示混合噪声识别及组合处理。配对可控参考：`v26_mixed_50hz_clean_reference.wav`。 |

第 1、2 项最适合耳听 A/B；网页图库会自动配对参考，也可手动展开“添加干净参考”。干净参考只用于本机评分，不会上传。第 3、4 项适合讲解频谱变化，第 5、7 项适合展示自然时频结构。第 8–10 项是本地生成的可控测试信号，用于验证噪声类型与算法路线，不代表现场录音；其实际分类和处理效果以板端本次返回为准。

## 下载来源、许可与样本性质

- 大阪道顿堀夜景：Martin Falbisoner，CC BY-SA 4.0，[Wikimedia Commons 文件页](https://commons.wikimedia.org/wiki/File:Dotonbori,_Osaka,_at_night,_November_2016.jpg)。低照版本为基于原图生成的输入。
- 金毛幼犬：MichaelMcPhee，CC BY 3.0，[Wikimedia Commons 文件页](https://commons.wikimedia.org/wiki/File:Callie_the_golden_retriever_puppy.jpg)。σ=25 噪声版本为基于原图生成的输入。
- Breda 街景：Fons Heijnsbroek，CC0，[Wikimedia Commons 文件页](https://commons.wikimedia.org/wiki/File:2023_-_free_download_photo_of_a_view_in_the_street_Veemarktstraat_in_Breda_with_a_plane_tree_in_the_middle_and_some_boys_on_skateboards_over_the_cobblestones._It_is_a_restaurant_street._Street_photography_of_Dutch_cities_in_high_res.tif)。
- 猫咪：Alvesgaspar，CC BY-SA 3.0，[Wikimedia Commons 文件页](https://commons.wikimedia.org/wiki/File:Cat_November_2010-1a.jpg)。此处使用 960 像素缩略图。
- 鸟鸣与雨声：Robert EA Harvey，CC BY-SA 4.0，[Wikimedia Commons 文件页](https://commons.wikimedia.org/wiki/File:Bourne_woods_Birdsong_and_rain_2020-06-17_0742.mp3)。上传 WAV 是原录音约 26–34 秒的单声道 48 kHz PCM16 片段；完整 MP3 在 `test_audio_samples/source_materials/`，略大于网页上传上限。
- 噪声语音、音乐盒和 Bell 录音的来源与许可见 `test_audio_samples/README.md`；单音、工频、低频轰鸣和混合噪声样本由本地脚本生成。

素材清单中的板端测量值来自已有 V24–V26 运行记录。新增猫咪照片和当前未列入板端记录的输入尚无对应板端效果数据，控制台应以新任务实际回传结果展示。
