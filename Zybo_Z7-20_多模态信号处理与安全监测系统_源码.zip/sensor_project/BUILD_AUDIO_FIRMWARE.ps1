$ErrorActionPreference = 'Stop'
$project = $PSScriptRoot
$firmware = Join-Path $project 'firmware'
$output = Join-Path $firmware 'sensor.elf'
$backup = Join-Path $firmware 'sensor_v12_backup.elf'
$builder = Join-Path (Split-Path $PSScriptRoot -Parent) "control_center\build_app.ps1"

if ((Test-Path $output) -and -not (Test-Path $backup)) {
    Copy-Item -LiteralPath $output -Destination $backup
    if (Test-Path ($output + '.map')) {
        Copy-Item -LiteralPath ($output + '.map') -Destination (Join-Path $firmware 'sensor_v12_backup.elf.map')
    }
}

& $builder -Source (Join-Path $firmware 'main.c') -Output $output -AdditionalSources @((Join-Path $firmware 'ble_service.c'), (Join-Path $firmware 'audio_dsp.c'), (Join-Path $firmware 'minimp3_impl.c')) -Optimization '2'
if ($LASTEXITCODE -ne 0) { throw 'ARM audio firmware build failed' }
Write-Host 'ARM audio firmware ready.'
