set root E:/zybo/sensor_project
create_project sonar_package $root/sonar_package -part xc7z020clg400-1 -force
add_files $root/rtl/sonar_axi.v
set_property top sonar_axi [current_fileset]
ipx::package_project -root_dir $root/ip_repo/sonar_axi -vendor zybo.lab -library user -taxonomy /UserIP -import_files -set_current true
set core [ipx::current_core]
set_property name sonar_axi $core
set_property display_name {MAXSONAR pulse capture and alarm} $core
set_property version 1.0 $core
set map [ipx::add_memory_map S_AXI $core]
set block [ipx::add_address_block Reg $map]
set_property base_address 0 $block
set_property range 64 $block
set_property width 32 $block
set_property usage register $block
set_property slave_memory_map_ref S_AXI [ipx::get_bus_interfaces S_AXI -of_objects $core]
ipx::create_xgui_files $core
ipx::update_checksums $core
ipx::check_integrity $core
ipx::save_core $core
puts {SONAR_IP_PACKAGED}
close_project
